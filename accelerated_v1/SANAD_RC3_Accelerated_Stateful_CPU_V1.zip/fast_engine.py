"""SANAD RC3 CPU candidate (not a new field-qualified model).

Sole scientific reference is frozen/rc3.py.  The estimator weights and
feature definitions are unchanged.  This candidate changes how trained trees
are *evaluated* and allows causal v35/v33 replay to run once on ingestion.

No first-alert claim.  RC3 still produces a decision only once 300 reports
have been ingested.  See EVIDENCE.md for limits and parity checks.
"""
from __future__ import annotations
import sys
from pathlib import Path
import hashlib
import numpy as np

ROOT = Path(__file__).resolve().parent
FROZEN = ROOT/'frozen'
assert FROZEN.is_dir(), 'Expected SHA-locked frozen RC3 release'
_SOURCE_SHA='18cccfaa9b27a17934bc2c3a1c22f0b7ed164b2af99c0ad738b33a595357a81e'
assert hashlib.sha256((FROZEN/'internal/rc0_runtime/feature_engineering.py').read_bytes()).hexdigest()==_SOURCE_SHA, 'Frozen feature source hash mismatch'
if str(FROZEN) not in sys.path: sys.path.insert(0,str(FROZEN))
from rc3 import FrozenRC3,meta_features,THRESHOLD
from fast_stats import make_features
import feature_engineering as fe
from sanad_v33 import ElementEvidence, EvidenceFusionV33, FusionConfigV33
from sanad_v35 import EvidenceFusionV35
from fast_trees import NumbaForest,warm_up
from fast_upstream import features_from_replay,calculate_79
from fast_stats import fast_feature_matrix

N=7;W=300

class FastRC3:
    def __init__(self):
        self.reference=FrozenRC3()  # trusted source hash validated on import
        m=self.reference
        self.bases=[NumbaForest(m.base_models[0]),m.base_models[1]]
        self.meta=NumbaForest(m.meta_model)
        self.rf=NumbaForest(m.rc0.bundle['trained_models']['rf_shallow'])
        self.logistic=m.rc0.bundle['trained_models']['logistic_L2']
        self.upstream_weight=m.rc0.bundle['weight']
        self.upstream_names=m.rc0.bundle['names']
        self.upstream_threshold=m.rc0.threshold
        assert self.upstream_weight=={'logistic_L2':0.5,'rf_shallow':0.5}
        self.prewarm()

    @staticmethod
    def prewarm():
        """JIT compile before accepting traffic; one-off startup excluded from p95."""
        warm_up()
        fast_feature_matrix(np.zeros((2,300,7,3)),np.zeros((300,7,3)),np.zeros((300,7)))
        calculate_79(np.zeros((300,7),dtype=np.bool_),np.zeros((300,7),dtype=np.int64),
            np.zeros((2,300,7,3)),np.zeros((300,7,3)),
            np.zeros((6,300,7),dtype=np.bool_),np.zeros((4,300,7),dtype=np.bool_))

    def _finish(self,trace,stream,upstream_matrix,columns):
        # Source upstream model requires precisely this frozen selected column list.
        colmap={k:i for i,k in enumerate(columns)}
        required=self.upstream_names+['v35_fired','v33_fired']
        if any(k not in colmap for k in required):raise ValueError('Frozen upstream features missing')
        raw=upstream_matrix[:,[colmap[k] for k in self.upstream_names]]
        p=.5*self.logistic.predict_proba(raw)[:,1]+.5*self.rf.predict_proba(raw)[:,1]
        # Re-evaluate borderline RC0 cases via the original estimator.
        if np.any(np.abs(p-self.upstream_threshold)<1e-9):
            p=.5*self.logistic.predict_proba(raw)[:,1]+.5*self.reference.rc0.bundle['trained_models']['rf_shallow'].predict_proba(raw)[:,1]
        flags=(upstream_matrix[:,colmap['v35_fired']]>0)&(p>=self.upstream_threshold)
        x=make_features(trace,stream)
        scores=.5*(self.bases[0].predict_proba(x)[:,1]+self.bases[1].predict_proba(x)[:,1])
        sp=meta_features(scores,flags)
        probs=self.meta.predict_proba(sp)[:,1]
        # Protect decisions near the frozen threshold against float summation differences.
        if np.any(np.abs(probs-THRESHOLD)<1e-9):
            probs=self.reference.meta_model.predict_proba(sp)[:,1]
        assert len(probs)==N and np.isfinite(probs).all()
        return {'alerts':(probs>=THRESHOLD).tolist(),
                'probabilities':probs.tolist(),'threshold':THRESHOLD}

    def predict_trace(self,trace,stream):
        fe._validate_observations_only(trace,stream)
        upstream,cols=features_from_replay(trace,stream,fe._replay_without_truth(trace,stream),validated=True)
        return self._finish(trace,stream,upstream,cols)

    def session(self,stream='healthy'):
        return RC3IngestionSession(self,stream)

class RC3IngestionSession:
    """Causal, incremental 300-report ingestion with unchanged terminal RC3.

    No early RC3 alarm is available. State is valid for ONE nonoverlapping
    300-report block and cannot be reused or shifted without a new session.
    """
    _f35=(('final','final_alert'),('review','review_candidate'),
          ('delta_persistent','delta_persistent'),('delta_supported','delta_supported'),
          ('delta_solo','delta_solo'),('cohort','cohort_ambiguous'))
    _f33=(('final','final_alert'),('strict','strict_v32'),
          ('corroborated','spatial_corroborated'),('confirmed_v11','confirmed_v11'))

    def __init__(self,engine:FastRC3,stream:str):
        if stream not in ('healthy','injected'):raise ValueError(stream)
        self.engine=engine;self.stream=stream
        self.a35=EvidenceFusionV35(fe.FROZEN_V35)
        self.a33=EvidenceFusionV33(FusionConfigV33())
        self.n=0
        # Fixed-size typed buffers: avoid per-report list growth, GC and np.stack.
        self.raw=np.empty((W,N),dtype=np.int8)
        self.names=np.empty((W,N),dtype=np.int16)
        self.feats=np.empty((2,W,N,3),dtype=np.float64)
        self.delta=np.empty((W,N,3),dtype=np.float64)
        self.flags35={k:np.zeros((W,N),dtype=np.bool_) for k,v in self._f35}
        self.flags33={k:np.zeros((W,N),dtype=np.bool_) for k,v in self._f33}

    @staticmethod
    def _mk(v):
        if np.isfinite(v).all():return ElementEvidence(float(v[0]),float(v[1]),int(v[2]))
        return None

    def push(self,raw_v11,raw_named,feats,delta):
        if self.n>=W: raise RuntimeError('300-report session complete; create a new session')
        raw_v11=np.asarray(raw_v11)
        raw_named=np.asarray(raw_named)
        feats=np.asarray(feats)
        delta=np.asarray(delta)
        if raw_v11.shape!=(N,) or raw_named.shape!=(N,) or feats.shape!=(2,N,3) or delta.shape!=(N,3):
            raise ValueError('Incorrect 7x8 frozen observation report shape')
        if not np.isfinite(raw_v11).all() or not np.isin(raw_v11,[0,1]).all():
            raise ValueError('Malformed input flag')
        if not np.isfinite(raw_named).all() or not np.equal(raw_named,np.floor(raw_named)).all() or np.any((raw_named<0)|(raw_named>8)):
            raise ValueError('Malformed antenna names')
        for trip in (feats.reshape(-1,3),delta.reshape(-1,3)):
            if np.isinf(trip).any() or np.any(np.isfinite(trip).any(axis=-1)&~np.isfinite(trip).all(axis=-1)):
                raise ValueError('Malformed or partially missing evidence')
        valid_delta=np.isfinite(delta).all(axis=-1)
        d=delta[valid_delta]
        if len(d) and (np.any(d[:,0]<0) or np.any(d[:,1]<0) or np.any(d[:,2]<1) or np.any(d[:,2]>8) or np.any(d[:,2]!=np.floor(d[:,2]))):
            raise ValueError('Invalid temporal evidence')
        valid_feat=np.isfinite(feats).all(axis=-1)
        f=feats.reshape(-1,3)[valid_feat.reshape(-1)]
        if len(f) and (np.any(f[:,0]<0) or np.any(f[:,1]<0) or np.any(f[:,2]<1) or np.any(f[:,2]>8) or np.any(f[:,2]!=np.floor(f[:,2]))):
            raise ValueError('Invalid spatial evidence')
        i=self.n
        self.raw[i]=raw_v11
        self.names[i]=raw_named
        self.feats[:,i]=feats
        self.delta[i]=delta
        fast=[self._mk(feats[0,j]) for j in range(N)]
        strict=[self._mk(feats[1,j]) for j in range(N)]
        temporal=[self._mk(delta[j]) for j in range(N)]
        v35=[bool(np.isfinite(feats[:,j,0]).any() or np.isfinite(delta[j,0])) for j in range(N)]
        v33=[bool(np.isfinite(feats[:,j,0]).any()) for j in range(N)]
        o35=self.a35.step(raw_v11.tolist(),raw_named.tolist(),fast,strict,temporal,v35)
        o33=self.a33.step(raw_v11.tolist(),raw_named.tolist(),fast,strict,v33)
        for name,attr in self._f35:self.flags35[name][i]=[bool(getattr(z,attr)) for z in o35]
        for name,attr in self._f33:self.flags33[name][i]=[bool(getattr(z,attr)) for z in o33]
        self.n+=1
        if self.n<W:return None
        return self.finalize()

    def finalize(self):
        if self.n!=W:raise RuntimeError('Terminal decision requires 300 reports')
        s=self.stream
        trace={f'{s}_v11':self.raw, f'{s}_v11_named':self.names,
               f'{s}_feats':self.feats, f'{s}_delta':self.delta}
        x,cols=features_from_replay(trace,s,(self.flags35,self.flags33),validated=True)
        return self.engine._finish(trace,s,x,cols)


def from_evidence(engine:FastRC3,trace,stream):
    """Drive replay via the same incremental interface as future live inputs."""
    session=engine.session(stream)
    out=None
    for t in range(W):
        out=session.push(trace[f'{stream}_v11'][t], trace[f'{stream}_v11_named'][t],
                         trace[f'{stream}_feats'][:,t],trace[f'{stream}_delta'][t])
    return out
