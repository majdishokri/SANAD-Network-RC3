"""Adversarial data-quality parity tests; do not estimate fault performance."""
from __future__ import annotations
from pathlib import Path
import argparse,json
import numpy as np
from fast_engine import FastRC3,from_evidence


def run(input_path,output_path=None):
    with np.load(input_path,allow_pickle=False) as z:base={k:z[k] for k in z.files}
    m=FastRC3();result=[]
    for name in ('missing_fast_block','missing_delta_block','common_mode_score','v11_zero','all_nan_station'):
        e={k:v.copy() for k,v in base.items()}
        if name=='missing_fast_block':e['injected_feats'][0,180:230,2,:]=np.nan
        elif name=='missing_delta_block':e['injected_delta'][190:230,1,:]=np.nan
        elif name=='common_mode_score':
            for i in (0,1):
                z=e['injected_feats'][i,260:,: ,0]
                z[np.isfinite(z)]+=0.15
        elif name=='v11_zero':
            e['injected_v11'][260:280,:]=0
            e['injected_v11_named'][260:280,:]=0
        elif name=='all_nan_station':
            e['injected_feats'][:,200:300,5,:]=np.nan
            e['injected_delta'][200:300,5,:]=np.nan
        a=m.reference.predict_trace(e,'injected')
        b=m.predict_trace(e,'injected')
        c=from_evidence(m,e,'injected')
        diff=max(abs(x-y) for x,y in zip(a['probabilities'],c['probabilities']))
        if a['alerts']!=b['alerts'] or a['alerts']!=c['alerts'] or diff>1e-6:
            raise RuntimeError(f'Edge parity failed: {name}, {diff}')
        result.append({'scenario':name,'max_probability_error':diff,'identical_alerts':True})
        print('EDGE_PARITY_PASS',name,round(diff,18),flush=True)
    if output_path:Path(output_path).write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--output')
    a=p.parse_args();run(a.input,a.output)
