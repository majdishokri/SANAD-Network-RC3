"""Numba optimization of frozen RC3's make_features ONLY.
Causal windows and order are identical.  Not a learned model change.
Requires full numerical differential verification before deployment.
"""
import numpy as np
from numba import njit

@njit(cache=True)
def _q(s,q):
    if s.size==0:return 0.0
    x=(s.size-1)*q
    lo=int(np.floor(x));hi=int(np.ceil(x))
    return float(s[lo]+(s[hi]-s[lo])*(x-lo))

@njit(cache=True)
def _st(vals,lo,hi,out,j,ind):
    buf=np.empty(hi-lo,dtype=np.float64)
    count=0
    for t in range(lo,hi):
        val=vals[t]
        if np.isfinite(val):
            buf[count]=val;count+=1
    if count==0:
        for k in range(9):out[j,ind+k]=0.0
        return ind+9
    s=np.sort(buf[:count])
    total=0.
    for k in range(count):total+=s[k]
    mean=total/count
    var=0.
    for k in range(count):var+=(s[k]-mean)**2
    out[j,ind]=float(count)
    out[j,ind+1]=mean
    out[j,ind+2]=np.sqrt(var/count)
    for qi,q in enumerate((0.1,0.25,0.5,0.75,0.9)):
        out[j,ind+3+qi]=_q(s,q)
    out[j,ind+8]=s[-1]
    return ind+9

@njit(cache=True)
def _med(vals,lo,hi):
    buf=np.empty(hi-lo,dtype=np.float64);count=0
    for t in range(lo,hi):
        if np.isfinite(vals[t]):
            buf[count]=vals[t];count+=1
    if count==0:return 0.0, False
    return _q(np.sort(buf[:count]),0.5), True

@njit(cache=True)
def fast_feature_matrix(f,d,v):
    # f (2,300,7,3), d (300,7,3), v(300,7).
    raw=np.empty((300,7,9),dtype=np.float64)
    for t in range(300):
        for j in range(7):
            for mode in range(2):
                for c in range(3):raw[t,j,mode*3+c]=f[mode,t,j,c]
            for c in range(3):raw[t,j,6+c]=d[t,j,c]
    relative=np.empty_like(raw)
    for t in range(300):
        for c in range(9):
            buf=np.empty(7,dtype=np.float64);k=0
            for j in range(7):
                z=raw[t,j,c]
                if not np.isnan(z):buf[k]=z;k+=1
            median=_q(np.sort(buf[:k]),0.5) if k else np.nan
            for j in range(7):relative[t,j,c]=raw[t,j,c]-median
    out=np.zeros((7,693),dtype=np.float64)
    for j in range(7):
        idx=0
        for source in range(2):
            z=raw if source==0 else relative
            for c in range(9):
                x=z[:,j,c]
                for l,r in ((180,220),(220,260),(260,300),(280,300)):
                    idx=_st(x,l,r,out,j,idx)
                mr,b=_med(x,260,300)
                mf,a=_med(x,220,260)
                out[j,idx]=mr-mf if a and b else 0.0
                idx+=1
        x=v[:,j]
        for l,r in ((180,220),(220,260),(260,300)):
            idx=_st(x,l,r,out,j,idx)
        assert idx==693
    res=np.empty((7,693),dtype=np.float32)
    for j in range(7):
        for i in range(693):
            a=out[j,i]
            res[j,i]=0.0 if np.isnan(a) else (1e6 if np.isposinf(a) else (-1e6 if np.isneginf(a) else a))
    return res

def make_features(trace,stream):
    f=np.asarray(trace[f'{stream}_feats'],dtype=np.float64)
    d=np.asarray(trace[f'{stream}_delta'],dtype=np.float64)
    v=np.asarray(trace[f'{stream}_v11'],dtype=np.float64)
    if f.shape!=(2,300,7,3) or d.shape!=(300,7,3) or v.shape!=(300,7):
        raise ValueError('Unexpected source trace schema')
    return fast_feature_matrix(f,d,v)
