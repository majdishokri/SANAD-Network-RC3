# SANAD Network RC3 — accelerated CPU execution candidate

The **original frozen RC3 is unmodified**. This candidate accelerates tree inference and endpoint features using Numba and ingests reports incrementally through original v33/v35 state machines. It does not permit an RC3 alarm before its 300th report and is not a new model release.

## Components

- `frozen/`: SHA-locked original private RC3 source/models and `verify_portable.py`. Do not redistribute; deploy only with authorization.
- `fast_engine.py`: accelerated stateless and causal 300-report stateful API.
- `fast_trees.py`: deterministic Numba evaluation of the original sklearn binary forests.
- `fast_stats.py`: compiled exact 693-feature math (float32 output).
- `fast_upstream.py`: compiled exact 79-feature upstream endpoint math.
- `service.py`: fixed-block, ordered synchronous ingestion with explicit no-actuation status.
- `tests.py`: strict differential regression and input-contract test.
- `validate_full.py`: Colab full 144-seed checkpoint-parity and CPU p50/p95/p99 benchmark.
- `performance_local.json`, `regression_local.json`, `ENGINEERING_REVIEW.md`: evidence and limitations.

## Use (Python 3.13 / CPU)

Install `pip install -r requirements-cpu.txt` into a fresh environment, then:

```bash
python frozen/verify_portable.py
python tests.py /path/to/s3143.npz
python validate_full.py --evidence /path/to/qualification_npz \
    --checkpoints /path/to/checkpoints --out /path/to/new_results
```

Or run the Colab notebook in your Google Drive (it uses a fresh Python child process to avoid NumPy kernel conflicts, verifies the bundle SHA and retrieves only missing evidence).

## Distinguish latency types

Ordinary *ingestion* and final *terminal scoring* p95 are distinct metrics. This model does **not** produce first-alert TTD before report 300. Full input front-end RF capture, covariance, preprocessing and network I/O time are excluded. All experiments use simulated Sionna observations; no field detection qualifications.

`python edge_cases.py /path/to/s3143.npz` tests five input-quality edge scenarios against the original frozen model. This is differential implementation testing, not an operational fault test.
