"""Research-only, deterministic tiny-batch CPU evaluation for frozen sklearn forests.
Loaded trees/weights are unchanged. Do not use untrusted serialized estimators.
Numba JIT compilation is excluded from warm inference timings.
"""
import numpy as np
from numba import njit

@njit(cache=True)
def forest_eval(x, left, right, feat, thr, prob, lengths):
    n=x.shape[0]
    out=np.zeros(n,dtype=np.float64)
    trees=lengths.size
    for k in range(trees):
        for i in range(n):
            node=0
            while left[k,node] >= 0:
                idx=feat[k,node]
                if x[i,idx] <= thr[k,node]:
                    node=left[k,node]
                else:
                    node=right[k,node]
            out[i]+=prob[k,node]
    return out/trees

class NumbaForest:
    def __init__(self,skforest):
        ts=skforest.estimators_
        if skforest.n_classes_ != 2 or list(skforest.classes_) != [0,1]:
            raise ValueError('Only binary class [0,1] classifiers')
        nt=len(ts)
        lengths=np.array([t.tree_.node_count for t in ts],dtype=np.int32)
        size=max(lengths)
        left=np.full((nt,size),-1,dtype=np.int32)
        right=np.full((nt,size),-1,dtype=np.int32)
        feat=np.zeros((nt,size),dtype=np.int32)
        thr=np.zeros((nt,size),dtype=np.float64)
        p=np.zeros((nt,size),dtype=np.float64)
        for k,t in enumerate(ts):
            tr=t.tree_
            z=tr.node_count
            left[k,:z]=tr.children_left
            right[k,:z]=tr.children_right
            feat[k,:z]=tr.feature
            thr[k,:z]=tr.threshold
            p[k,:z]=tr.value[:,0,1] # normalized leaf posterior in sklearn 1.8
        self.params=(left,right,feat,thr,p,lengths)

    def predict_proba(self,X):
        X=np.asarray(X,dtype=np.float32)
        p=forest_eval(X,*self.params)
        return np.column_stack([1.-p,p])

def warm_up():
    # JIT compile: tiny valid shape with leaf-only tree.
    x=np.zeros((1,1),dtype=np.float32)
    a=np.array([[-1]],dtype=np.int32)
    t=np.zeros((1,1),dtype=np.float64)
    n=np.array([1],dtype=np.int32)
    forest_eval(x,a,a,a,t,t,n)
