"""Research optimization of the *unchanged* 79 frozen RC0 features.

Numba implementation of feature_engineering.features_per_array's endpoint
statistics, after original v33/v35 causal replay has been performed.
Feature definitions and order verified against SHA-locked original source.
"""
import numpy as np
from numba import njit
from fast_stats import _q

FEATURE_NAMES=('v11_count40','v11_count20','v11_count12','v11_modal_count40',
'v11_modal_frac40','v11_unique_name_count','v11_last10_count',
'fast_valid_fraction','fast_score_median','fast_score_max','fast_score_p90',
'fast_score_last10_mean','fast_dom_median','fast_dom_max','fast_dom_p90',
'fast_dom_last10_mean','fast_score_early20','fast_score_late20','fast_strong_count40',
'fast_modal_count40','fast_modal_fraction','fast_last10_strong','fast_peak_coherent_score',
'fast_modal_id','strict_valid_fraction','strict_score_median','strict_score_max',
'strict_score_p90','strict_score_last10_mean','strict_dom_median','strict_dom_max',
'strict_dom_p90','strict_dom_last10_mean','strict_score_early20','strict_score_late20',
'strict_strong_count40','strict_modal_count40','strict_modal_fraction',
'strict_last10_strong','strict_peak_coherent_score','strict_modal_id','delta_valid_fraction',
'delta_score_median','delta_score_max','delta_score_p90','delta_score_last10_mean',
'delta_dom_median','delta_dom_max','delta_dom_p90','delta_dom_last10_mean',
'delta_score_early20','delta_score_late20','delta_strong_count40',
'delta_modal_count40','delta_modal_fraction','delta_last10_strong',
'delta_peak_coherent_score','delta_modal_id','fast_strict_same_element',
'delta_strict_same_element','delta_fast_same_element','delta_v11_same_element',
'strict_v11_same_element','delta_coincidence_with_raw','strict_coincidence_with_raw',
'v35_alert_count40','v33_alert_count40','v35_review_count40',
'v35_temporal_persistent_count40','v35_temporal_supported_count40',
'v35_temporal_solo_count40','v35_cohort_count40','v33_strict_count40',
'v33_corroborated_count40','v33_v11_count40','v35_fired','v33_fired',
'v35_group_max_active','v35_group_mean_active')
assert len(FEATURE_NAMES)==79
K35=('final','review','delta_persistent','delta_supported','delta_solo','cohort')
K33=('final','strict','corroborated','confirmed_v11')

@njit(cache=True)
def mode_count(names,hits):
    counts=np.zeros(9,dtype=np.int64)
    valid=0
    for t in range(40):
        if hits[t] and 1<=names[t]<=8:
            counts[names[t]]+=1;valid+=1
    if valid==0:return 0,0,0
    idx=1
    for i in range(2,9):
        if counts[i]>counts[idx]:idx=i
    return idx,int(counts[idx]),valid

@njit(cache=True)
def calculate_79(raw,named,feats,delta,flags35,flags33):
    out=np.zeros((7,79),dtype=np.float64)
    v35_n_active=np.zeros(40,dtype=np.int64)
    for tt in range(40):
        for aa in range(7):v35_n_active[tt]+=flags35[0,260+tt,aa]
    max_active=float(np.max(v35_n_active)); mean_active=float(np.mean(v35_n_active))
    for a in range(7):
        raw40=raw[260:300,a];names=named[260:300,a]
        out[a,0]=float(np.sum(raw40));out[a,1]=float(np.sum(raw[280:300,a]));out[a,2]=float(np.sum(raw[288:300,a]))
        modal,nc,nt=mode_count(names,raw40)
        out[a,3]=nc;out[a,4]=float(nc/max(nt,1))
        # Number of different 1..8 IDs that are active and nonzero in raw40.
        seen=np.zeros(9,dtype=np.bool_)
        for t in range(40):
            if raw40[t] and 1<=names[t]<=8:seen[names[t]]=True
        out[a,5]=float(np.sum(seen))
        out[a,6]=float(np.sum(raw[290:300,a]))
        modal_arr=np.zeros(3,dtype=np.int64)
        hit_arr=np.zeros((3,40),dtype=np.bool_)
        base=7
        for view in range(3):
            s=np.empty(40,dtype=np.float64)
            d=np.empty(40,dtype=np.float64)
            nm=np.empty(40,dtype=np.int64)
            valid=np.zeros(40,dtype=np.bool_)
            scorethr=.7687096042171566 if view!=2 else 4.0
            dominance_thr=1.5 if view==0 else (1.8 if view==1 else 1.45)
            for t in range(40):
                e=delta[260+t,a] if view==2 else feats[view,260+t,a]
                good=np.isfinite(e[0]) and np.isfinite(e[1]) and np.isfinite(e[2])
                valid[t]=good
                s[t]=float(e[0]) if np.isfinite(e[0]) else 0.0
                d[t]=float(e[1]) if np.isfinite(e[1]) else 0.0
                nm[t]=int(e[2]) if np.isfinite(e[2]) else 0
                hit_arr[view,t]=bool(good and e[0]>=scorethr and e[1]>=dominance_thr)
            out[a,base]=float(np.mean(valid));base+=1
            for vec in (s,d):
                sort=np.sort(vec)
                out[a,base]=_q(sort,.5);base+=1
                out[a,base]=float(np.max(vec));base+=1
                out[a,base]=_q(sort,.9);base+=1
                out[a,base]=float(np.mean(vec[-10:]));base+=1
            out[a,base]=float(np.mean(s[:20]));base+=1
            out[a,base]=float(np.mean(s[20:]));base+=1
            h=hit_arr[view]
            winner,mcount,ncount=mode_count(nm,h)
            modal_arr[view]=winner
            out[a,base]=float(np.sum(h));base+=1
            out[a,base]=float(mcount);base+=1
            out[a,base]=float(mcount/max(ncount,1));base+=1
            out[a,base]=float(np.sum(h[30:]));base+=1
            peak=0.0
            for t in range(40):
                if h[t] and s[t]>peak:peak=s[t]
            out[a,base]=peak;base+=1
            out[a,base]=float(winner if view==2 else 0);base+=1
        assert base==58
        fastid,strictid,deltaid=modal_arr
        out[a,58]=(1.0 if (fastid>0 and fastid==strictid) else 0.0)
        out[a,59]=(1.0 if (deltaid>0 and deltaid==strictid) else 0.0)
        out[a,60]=(1.0 if (deltaid>0 and deltaid==fastid) else 0.0)
        out[a,61]=(1.0 if (deltaid>0 and deltaid==modal) else 0.0)
        out[a,62]=(1.0 if (strictid>0 and strictid==modal) else 0.0)
        out[a,63]=float(np.sum(hit_arr[2]&raw40))
        out[a,64]=float(np.sum(hit_arr[1]&raw40))
        out[a,65]=float(np.sum(flags35[0,260:300,a]))
        out[a,66]=float(np.sum(flags33[0,260:300,a]))
        for k in range(1,6):out[a,66+k]=float(np.sum(flags35[k,260:300,a]))
        for k in range(1,4):out[a,71+k]=float(np.sum(flags33[k,260:300,a]))
        out[a,75]=(1.0 if (np.any(flags35[0,260:300,a])) else 0.0)
        out[a,76]=(1.0 if (np.any(flags33[0,260:300,a])) else 0.0)
        out[a,77]=max_active
        out[a,78]=mean_active
    return out

def features_from_replay(trace,stream,replay, *, validated=False):
    # Fast endpoint stats from frozen, causal 300-report observations and replay.
    # Caller must have validated each report before calling with validated=True.
    if not validated:
        import feature_engineering as fe
        fe._validate_observations_only(trace,stream)
    f35,f33=replay
    arrays=[np.asarray(f35[k],dtype=np.bool_) for k in K35]
    arrays33=[np.asarray(f33[k],dtype=np.bool_) for k in K33]
    if any(a.shape!=(300,7) for a in arrays+arrays33):raise ValueError('Replay shape invalid')
    x=calculate_79(np.asarray(trace[f'{stream}_v11'],dtype=np.bool_),
        np.asarray(trace[f'{stream}_v11_named'],dtype=np.int64),
        np.asarray(trace[f'{stream}_feats'],dtype=np.float64),
        np.asarray(trace[f'{stream}_delta'],dtype=np.float64),
        np.stack(arrays),np.stack(arrays33))
    assert x.shape==(7,79) and np.isfinite(x).all()
    return x,list(FEATURE_NAMES)
