"""Offline frozen RC3 integrity check for the portable original-source reconstruction."""
from pathlib import Path
import hashlib,gzip,json
ROOT=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
m=json.loads((ROOT/'PORTABLE_RELEASE_LOCK.json').read_text())
assert sha((ROOT/'rc3.py').read_bytes())==m['root_rc3_sha256']
c=(ROOT/'model/rc3_candidate.joblib.gz').read_bytes()
assert sha(c)==m['compressed_model_sha256']
assert sha(gzip.decompress(c))==m['uncompressed_model_sha256']
assert sha((ROOT/'internal/rc0_runtime/frozen_candidate/selected_model.joblib').read_bytes())==m['internal_rc0_model_sha256']
assert sha((ROOT/'qualification/SUMMARY_FROZEN.json').read_bytes())=='cda17210aeb4450b1d0a67eded5c2959fc5e4ed371bb170cf44791f3201cdabd'
assert sha((ROOT/'qualification/MANIFEST_FROZEN.json').read_bytes())=='c22c6a62151292d120e58df1806bf289fa9750a7594cf83137d7754431b75140'
s=json.loads((ROOT/'qualification/SUMMARY_FROZEN.json').read_text())
rc3=s['methods']['RC3']
assert (rc3['tp'],rc3['fault_n'],rc3['healthy_fp'],rc3['healthy_n'],rc3['neighbor_fp'])==(274,288,0,1008,13)
assert s['frozen_threshold']==0.5
assert m['threshold']==0.5 and m['geometry']==[7,8]
print('FROZEN_RC3_PORTABLE_VERIFY_PASS: original release source and model SHA256 verified')
