import json,numpy as np
from unittest.mock import patch
from pathlib import Path
from inference_v35_gate import FrozenV35LearnedGate
from prospective_gpu_runner import score_seed, summary,NEW_SEEDS,STUDY

def test_seed_set_new_and_disjoint():
 assert len(NEW_SEEDS)==144 and NEW_SEEDS[0]==2500 and NEW_SEEDS[-1]==2643
 assert not set(NEW_SEEDS)&set(range(1264,1408))

def test_score_on_existing_example_is_label_only_in_scoring():
 p=Path('/mnt/data/s1264.npz')
 if not p.exists():return
 model=FrozenV35LearnedGate()
 with patch('prospective_gpu_runner.torch.cuda.get_device_name',return_value='QA_CPU_FIXTURE'):
  x=score_seed(1264,p,model,'sourcehash','modelhash','covhash')
 assert x['protocol']==STUDY and x['methods']['learned']['tp'] in (0,1,2)
 assert x['methods']['v35']['tp'] in (0,1,2)
 assert x['methods']['v35']['fp']<=7
 assert x['methods']['v33']['fp']<=7
 assert x['methods']['learned']['fp']<=x['methods']['v35']['fp']

def test_summary_partial_does_not_claim_qualification():
 r={'seed':2500,'methods':{k:{'tp':1,'fp':0,'neighbor_fp':0} for k in ('learned','v35','v33','v11')}}
 out=summary([r])
 assert out['status']=='INCOMPLETE' and out['qualification'] is None
 assert out['methods']['learned']['fault_n']==2
