"""SANAD v33 prospective protocol — NEVER tune on evaluation seeds.

Development: 888..911 (24 independently generated channel seeds)
Independent qualification: 912..1055 (144 separately generated channel seeds)
Each seed: 7 healthy arrays; one 2-fault injection stream; 300 15-min reports.
Dependence: seven arrays share a channel seed (bootstrap clusters by seed).
"""
from __future__ import annotations
from dataclasses import asdict, replace
from pathlib import Path
import hashlib, json, os, tempfile, itertools
import numpy as np
from sanad_v33 import FusionConfigV33
from v33_replay import replay_trace
from v32_replay import extract_seed, gate_evidence
from sanad_v32 import FusionConfig
from qualification import wilson, validate_covariance

DEV=tuple(range(888,912))
TEST=tuple(range(912,1056))
PROTOCOL='V33_PARALLEL_EVIDENCE_FUSION_SIONNA_DEVELOPMENT_888_911_PROSPECTIVE_912_1055'
SOURCE_FILES=['sanad_v33.py','v33_replay.py','v33_study.py','sanad_v32.py',
              'v32_replay.py','v32_prospective.py','sanad_v30.py','sanad_v29.py',
              'v29_research.py','detect_v11.py','monitor_v8.py','glr_compare.py',
              'qualification.py','sionna_gen.py','config_frozen.json']
OLD_V30_CONFIG=FusionConfig(score_threshold=0.7687096042171566,dominance_ratio=1.5,
                     persistence=8,recent=12,v11_confirm_min=1,v11_confirm_window=1,
                     v11_identity_min=0)
OLD_V32_CONFIG=FusionConfig(score_threshold=0.7687096042171566,dominance_ratio=1.8,
                     persistence=10,recent=15,v11_confirm_min=5,v11_confirm_window=8,
                     v11_identity_min=3)


def hash_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def frozen_source_hash(root):
    root=Path(root)
    h=hashlib.sha256()
    for name in SOURCE_FILES:
        h.update(name.encode()+b'\0'+bytes.fromhex(hash_file(root/name)))
    return h.hexdigest()


def atomic_json(path, obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',encoding='utf8',dir=path.parent,prefix=path.stem,suffix='.tmp',delete=False) as f:
        json.dump(obj,f,indent=2,sort_keys=True)
        tmp=f.name
    os.replace(tmp,path)


def candidate_configs():
    # SMALL FIXED engineering design space. Do not add or change after
    # prospective TEST 912..1055 observations have been accessed.
    baseline=FusionConfigV33()
    specs=[
        dict(corroboration_hits=2,v11_hits=5,strict_hits=10),
        dict(corroboration_hits=1,v11_hits=5,strict_hits=10),
        dict(corroboration_hits=3,v11_hits=5,strict_hits=10),
        dict(corroboration_hits=2,v11_hits=4,strict_hits=10),
        dict(corroboration_hits=1,v11_hits=4,strict_hits=10),
        dict(corroboration_hits=2,v11_hits=6,strict_hits=10),
        dict(corroboration_hits=1,v11_hits=5,strict_hits=12),
        dict(corroboration_hits=2,v11_hits=5,strict_hits=12),
    ]
    return [replace(baseline,**x) for x in specs]


def trace_metrics(trace,config:FusionConfigV33):
    old_methods={m:dict(healthy_fp=0, fault_tp=0, post_onset_tp=0, neighbor_fp=0,
                        delay_reports=[], terminal_named_correct=0, named_when_alerted=0)
                 for m in ('v11','v30','v32','v33')}
    extra=dict(review_healthy=0,review_fault=0,review_only_healthy=0,review_only_fault=0,
               spatial_confirmed_fault=0,v11_confirmed_fault=0)
    for stream in ('healthy','injected'):
        raw=trace[f'{stream}_v11'].astype(bool)
        named=trace[f'{stream}_v11_named']
        feats=trace[f'{stream}_feats']
        onsets=trace[f'{stream}_onset']
        expected=trace[f'{stream}_expected']
        v30,_,c30=gate_evidence(raw,feats,OLD_V30_CONFIG,raw_named=named)
        v32,_,c32=gate_evidence(raw,feats,OLD_V32_CONFIG,raw_named=named)
        out=replay_trace(trace,stream,config)
        flags={'v11':raw,'v30':v30,'v32':v32,'v33':out['final']}
        for a in range(7):
            if stream=='healthy':
                extra['review_healthy']+=int(out['review'][260:,a].any())
                extra['review_only_healthy']+=int(out['review_only'][260:,a].any())
            elif expected[a]>0:
                extra['review_fault']+=int(out['review'][260:,a].any())
                extra['review_only_fault']+=int(out['review_only'][260:,a].any())
                extra['spatial_confirmed_fault']+=int(out['corroborated'][260:,a].any())
                extra['v11_confirmed_fault']+=int(out['confirmed_v11'][260:,a].any())
            for m,x in flags.items():
                d=old_methods[m]
                present=bool(x[260:,a].any())
                if stream=='healthy':
                    d['healthy_fp']+=int(present)
                elif expected[a]>0:
                    d['fault_tp']+=int(present)
                    ons=int(onsets[a]); after=np.flatnonzero(x[ons:,a]);found=bool(len(after))
                    d['post_onset_tp']+=int(found)
                    if found:d['delay_reports'].append(int(after[0]))
                    # report-time output: terminal name estimated at report 299.
                    if m=='v11':
                        pred_name=int(named[-1,a]) if raw[-1,a] else 0
                    elif m=='v30':
                        pred_name=int(named[-1,a]) if raw[-1,a] else 0
                        if not pred_name and c30[-1,a] and np.isfinite(feats[0,-1,a,2]):pred_name=int(feats[0,-1,a,2])
                    elif m=='v32':
                        pred_name=int(named[-1,a]) if raw[-1,a] else 0
                        if not pred_name:
                            last=named[-OLD_V32_CONFIG.v11_confirm_window:,a]
                            last=last[last>0]
                            if len(last):pred_name=int(np.bincount(last).argmax())
                        if not pred_name and c32[-1,a] and np.isfinite(feats[1,-1,a,2]):pred_name=int(feats[1,-1,a,2])
                    else:
                        pred_name=int(out['antenna'][-1,a])
                    correct=int(pred_name==int(expected[a]))
                    d['terminal_named_correct']+=correct
                    d['named_when_alerted']+=correct*int(present)
                else:d['neighbor_fp']+=int(present)
    return {'methods':old_methods,'review':extra}


def evaluate_seed(seed, group, cov_dir, cache_dir, run_dir, src_dir, source_sha, config):
    allowed=DEV if group=='development' else TEST
    if seed not in allowed:raise ValueError(f'Forbidden seed for {group}: {seed}')
    dest=Path(run_dir)/f's{seed}.json'
    if dest.exists():
        old=json.loads(dest.read_text())
        if old.get('source_sha256')!=source_sha or old.get('protocol')!=PROTOCOL or old.get('group')!=group:
            raise ValueError('Existing checkpoint has different source/protocol/group')
        return old
    p=Path(cov_dir)/f's{seed}.npz'
    if not p.is_file():raise FileNotFoundError(f'Need NEW Sionna covariance: {p}')
    with np.load(p,allow_pickle=False) as z:validate_covariance(z[f's{seed}'])
    cache=Path(cache_dir)/f's{seed}.npz'
    if not cache.exists():extract_seed(p,src_dir,seed,cache)
    with np.load(cache,allow_pickle=False) as z:trace=dict(z)
    result={'protocol':PROTOCOL,'group':group,'seed':seed,'source_sha256':source_sha,
            'covariance_sha256':hash_file(p),
            'config':asdict(config),'research_only':True,
            **trace_metrics(trace,config)}
    atomic_json(dest,result)
    return result


def summarize_run(run_dir,seeds,config,source_sha,*,group,boots=1500):
    expected=DEV if group=='development' else TEST
    if tuple(seeds)!=expected:raise ValueError('Wrong seed group or range')
    rows={}
    for seed in seeds:
        fn=Path(run_dir)/f's{seed}.json'
        if not fn.exists():continue
        obj=json.loads(fn.read_text())
        if (obj.get('seed')!=seed or obj.get('source_sha256')!=source_sha or
            obj.get('protocol')!=PROTOCOL or obj.get('group')!=group or obj.get('config')!=asdict(config)):
            raise ValueError(f'Frozen run integrity mismatch {fn}')
        rows[seed]=obj
    n=len(rows)
    result={'status':'COMPLETE' if n==len(seeds) else 'INCOMPLETE',
            'group':group,'completed':n,'required':len(seeds),
            'source_sha256':source_sha,'protocol':PROTOCOL,
            'config':asdict(config),'methods':{},
            'acceptance':None,'research_only':True}
    if not n:return result
    for m in ('v11','v30','v32','v33'):
        total=lambda k:sum(r['methods'][m][k] for r in rows.values())
        fp=int(total('healthy_fp'));tp=int(total('fault_tp'))
        delays=[z for r in rows.values() for z in r['methods'][m]['delay_reports']]
        result['methods'][m]={'fault_tp':tp,'fault_n':2*n,'recall':tp/(2*n),
            'healthy_fp':fp,'healthy_n':7*n,'fpr':fp/(7*n),
            'wilson_false_ci':wilson(fp,7*n),
            'median_detection_delay_h':float(np.median(delays))/4 if delays else None,
            'correct_named_terminal':int(total('terminal_named_correct')),
            'correct_named_when_alerted':int(total('named_when_alerted')),
            'neighbor_fp':int(total('neighbor_fp'))}
    if boots and n>1:
        rng=np.random.default_rng(331011)
        idx=rng.integers(0,n,size=(boots,n))
        ids=list(rows)
        for m in ('v11','v30','v32','v33'):
            f=np.asarray([rows[s]['methods'][m]['healthy_fp'] for s in ids])
            t=np.asarray([rows[s]['methods'][m]['fault_tp'] for s in ids])
            result['methods'][m]['cluster_false_ci']=np.quantile(f[idx].sum(axis=1)/(7*n),[.025,.975]).tolist()
            result['methods'][m]['cluster_recall_ci']=np.quantile(t[idx].sum(axis=1)/(2*n),[.025,.975]).tolist()
        for base in ('v11','v30','v32'):
            diff=np.asarray([rows[s]['methods']['v33']['fault_tp']-rows[s]['methods'][base]['fault_tp'] for s in ids])
            result[f'paired_gain_v33_vs_{base}_ci95']=np.quantile(diff[idx].sum(axis=1)/(2*n),[.025,.975]).tolist()
    result['review']={key:sum(r['review'][key] for r in rows.values()) for key in ('review_healthy','review_fault','review_only_healthy','review_only_fault','spatial_confirmed_fault','v11_confirmed_fault')}
    if result['status']=='COMPLETE' and group=='prospective':
        v=result['methods']['v33']
        low=result['paired_gain_v33_vs_v11_ci95'][0]
        result['acceptance']={'passed':bool(v['wilson_false_ci'][1]<.02 and v['cluster_false_ci'][1]<.02
                                             and v['recall']>=.9 and low>0),
            'rule':'Wilson and cluster upper FAR 95% <2%; recall >=90%; paired seed-bootstrap v33-v11 recall gain lower bound >0',
            'wilson_false_upper':v['wilson_false_ci'][1],
            'cluster_false_upper':v['cluster_false_ci'][1],
            'paired_recall_gain_lower_v11':low}
    return result


def score_configs(dev_cache_dir):
    """Select only on 888-911; never call on any other seed set."""
    from dataclasses import asdict
    caches={}
    for sd in DEV:
        path=Path(dev_cache_dir)/f's{sd}.npz'
        if not path.exists():raise FileNotFoundError(f'Fresh development evidence missing {path}')
        with np.load(path,allow_pickle=False) as f:caches[sd]=dict(f)
    rows=[]
    for config in candidate_configs():
        arr=[trace_metrics(tr,config) for tr in caches.values()]
        tp=sum(r['methods']['v33']['fault_tp'] for r in arr)
        fp=sum(r['methods']['v33']['healthy_fp'] for r in arr)
        n=len(DEV)
        recall=tp/(2*n);fpr=fp/(7*n)
        feasible=recall>=.90 and fpr<=.02
        # Preregistered development ranking: prefer feasible candidates,
        # then lower FPR, then higher recall. If none feasible, optimize
        # a fixed feasibility-distance; do not infer qualification from it.
        loss=5*max(0,fpr-.02)+3*max(0,.9-recall)+.4*fpr-.1*recall
        rows.append({'config':asdict(config),'recall':recall,'fpr':fpr,
                     'fault_tp':tp,'healthy_fp':fp,'feasible_point':feasible,
                     'loss':loss})
    feasible=[r for r in rows if r['feasible_point']]
    chosen=(sorted(feasible,key=lambda r:(r['fpr'],-r['recall']))[0] if feasible else
            sorted(rows,key=lambda r:(r['loss'],r['fpr'],-r['recall']))[0])
    return {'status':'COMPLETE','protocol':PROTOCOL,
            'development_seeds':list(DEV),'research_only':True,
            'qualifying_development_points':len(feasible),
            'selected':chosen,'grid':rows,
            'note':'Model selection ONLY on new development seeds. Prospective 912..1055 not touched; 24 seeds are too few for a robust <2% upper CI claim.'}
