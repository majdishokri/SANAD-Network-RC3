"""Train a research-only v35 alert confirmation model on historical, ALREADY VIEWED seeds.

No hyperparameter or threshold selection on the retrospective evaluation block.
Never describe the evaluation block as fresh/prospective/independent validation.
The frozen v35 detector remains unchanged. No RF hardware actuation.
"""
from __future__ import annotations
import argparse,json, hashlib, pathlib
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier,RandomForestClassifier,ExtraTreesClassifier
from sklearn.metrics import roc_auc_score,average_precision_score
from qualification import wilson
import joblib

TRAIN=list(range(1264,1344)) # 80 already-inspected simulator seeds
CAL=list(range(1344,1376))   # 32 already-inspected simulator seeds
TEST=list(range(1376,1408))  # 32 already-inspected simulator seeds
assert set(TRAIN).isdisjoint(CAL) and set(TRAIN).isdisjoint(TEST) and set(CAL).isdisjoint(TEST)


def models():
 return {
  'logistic_L2':Pipeline([('z',StandardScaler()),('lr',LogisticRegression(max_iter=3000,C=.10,class_weight='balanced'))]),
  'hgb_shallow':HistGradientBoostingClassifier(max_iter=130,learning_rate=.045,max_leaf_nodes=5,min_samples_leaf=12,l2_regularization=8.,random_state=35),
  'rf_shallow':RandomForestClassifier(n_estimators=300,max_depth=5,min_samples_leaf=5,max_features=.65,class_weight='balanced_subsample',random_state=35,n_jobs=2),
  'extra_shallow':ExtraTreesClassifier(n_estimators=300,max_depth=5,min_samples_leaf=5,max_features=.65,class_weight='balanced',random_state=35,n_jobs=2),
 }


def measures(score,thr,x,y,stream):
 predicted=(x)&(score>=thr)
 pos=y==1
 healthy=(y==0)&(stream=='healthy')
 neighbor=(y==0)&(stream=='injected')
 tp=int((predicted&pos).sum());fp=int((predicted&healthy).sum());near=int((predicted&neighbor).sum())
 npos=int(pos.sum());nh=int(healthy.sum())
 ci=wilson(fp,nh)
 return {'tp':tp,'fault_n':npos,'recall':tp/max(npos,1),'fp':fp,'healthy_n':nh,'far':fp/max(nh,1),
         'neighbor_fp':near,'wilson_far_upper_95':float(ci[1]),'threshold':float(thr)}


def calc_objective(x):
 # FAR upper is our primary risk constraint; recall point next.
 far=x['far'];rec=x['recall'];ci=x['wilson_far_upper_95']
 return 2*max(0.,.9-rec)+5*max(0.,ci-.02)+2*far+(.95-rec)*.02


def find_threshold(scores,x,y,stream):
 # Exact threshold scan, calibration only; no retrospective test access.
 unique=np.unique(scores[x]); candidates=np.concatenate(([0.],unique,np.array([1.00001])))
 rows=[measures(scores,float(v),x,y,stream) for v in candidates]
 feasible=[r for r in rows if r['recall']>=.90 and r['wilson_far_upper_95']<.02]
 if feasible:
  selected=max(feasible,key=lambda r:(r['recall'],-r['far'],r['threshold']))
 else:
  selected=min(rows,key=lambda r:(calc_objective(r),-r['recall'],r['far']))
 return selected, bool(feasible),len(feasible)


def main():
 p=argparse.ArgumentParser();p.add_argument('--features',default=str(pathlib.Path(__file__).parent/'historical_features.npz'));p.add_argument('--outdir',default=str(pathlib.Path(__file__).parent/'model'));a=p.parse_args()
 dst=pathlib.Path(a.outdir);dst.mkdir(parents=True,exist_ok=True)
 with np.load(a.features) as z:
  data={k:z[k] for k in z.files}
 X=data['X'];y=data['y'];seeds=data['seed'];stream=data['stream'];cols=[str(x) for x in data['columns']]
 # Omit simulator stream, seed, array index, cross-array co-alert shortcut, and antenna ID.
 included=[i for i,c in enumerate(cols) if not(c.startswith('v35_group') or c.endswith('_modal_id') or c=='v35_fired')]
 names=[cols[i] for i in included]
 XX=X[:,included];active=X[:,cols.index('v35_fired')]>0
 tr=np.isin(seeds,TRAIN);cal=np.isin(seeds,CAL);te=np.isin(seeds,TEST)
 assert len(set(seeds[tr]))==80 and len(set(seeds[cal]))==32 and len(set(seeds[te]))==32
 assert int(y[tr].sum())==160 and int(y[cal].sum())==64 and int(y[te].sum())==64
 baselines={}
 for name,flag in [('v35',active),('v33',X[:,cols.index('v33_fired')]>0)]:
  baselines[name]={split:measures(flag[mask].astype(float),.5,flag[mask],y[mask],stream[mask]) for split,mask in [('train',tr),('calibration',cal),('evaluation',te)]}
 candidates=[]
 for model_name,model in models().items():
  # Candidate-positive training only; negatives include healthy-only + unaffected neighbors.
  model.fit(XX[tr&active],y[tr&active])
  pcal=np.zeros(int(cal.sum())); ptest=np.zeros(int(te.sum()))
  pcal[:]=model.predict_proba(XX[cal])[:,1]
  threshold,feasible,nfeasible=find_threshold(pcal,active[cal],y[cal],stream[cal])
  ptest[:]=model.predict_proba(XX[te])[:,1]
  outcome=measures(ptest,threshold['threshold'],active[te],y[te],stream[te])
  entry={'model':model_name,'calibration':threshold,'feasible_calibration':feasible,'num_feasible_thresholds':nfeasible,
         'evaluation':outcome,'train_candidate_examples':int((tr&active).sum()),
         'train_candidate_faults':int((tr&active&(y==1)).sum())}
  candidates.append(entry)
  print(model_name,'cal recall',round(threshold['recall'],3),'cal far',round(threshold['far'],3),'wilson',round(threshold['wilson_far_upper_95'],3),
        'RETRO EVAL recall',round(outcome['recall'],3),'far',round(outcome['far'],3),'FP',outcome['fp'],flush=True)
  joblib.dump({'model':model,'feature_names':names,'threshold':float(threshold['threshold']),'candidate_only':True,
               'source_legacy':'v35_legacy_union','train_seeds':TRAIN,'calibration_seeds':CAL,
               'evaluation_seeds_retrospective':TEST},dst/f'{model_name}.joblib')
 # Select only by CAL scores, never TEST outcomes.
 chosen=min(candidates,key=lambda r:(0 if r['feasible_calibration'] else 1,
                                   calc_objective(r['calibration']),
                                   -r['calibration']['recall'],r['calibration']['far']))
 selected_name=chosen['model']; src=dst/f'{selected_name}.joblib'
 import shutil
 shutil.copy2(src,dst/'selected_model.joblib')
 report={'status':'HISTORICAL_TRAINED_NOT_QUALIFIED','disclosure':'All seeds 1264-1407 were previously viewed and reported as v35 prospective. The partition by seed prevents model fit leakage but is NOT independent validation.',
  'data':{'trace_seed_range':'1264-1407','train_seeds':TRAIN,'calibration_seeds':CAL,'retrospective_evaluation_seeds':TEST,
          'train_array_cases':int(tr.sum()),'cal_array_cases':int(cal.sum()),'evaluation_array_cases':int(te.sum()),
          'train_candidate_count':int((tr&active).sum()),'num_features':len(names),
          'feature_sha256':hashlib.sha256(pathlib.Path(a.features).read_bytes()).hexdigest()},
  'selected_on_calibration_only':selected_name,'baselines':baselines,'candidates':candidates,
  'acceptance':{'recall_min':.90,'wilson_far_upper_max':.02,
   'prospective_qualification_passed':False,'not_independent':True}}
 (dst/'train_result.json').write_text(json.dumps(report,indent=2))
 (dst/'feature_names.json').write_text(json.dumps(names,indent=2))
 print('\nSELECTED',selected_name,'cal',chosen['calibration'],'eval',chosen['evaluation'],flush=True)
 print('Report saved',dst/'train_result.json')

if __name__=='__main__':main()
