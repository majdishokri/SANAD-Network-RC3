"""Retrospective Sionna v35 archive replay, original v33/v35 plus new hybrid. NOT prospective."""
from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from hashlib import sha256
from qualification import wilson
from sanad_hybrid_v33_v35 import replay_cached_trace
import numpy as np, json
METHODS = ('sensitive_alert', 'conservative_alert', 'hybrid_alert', 'temporal_promoted')

def one(seed):
    p = Path(f'/mnt/data/s{seed}.npz')
    h = replay_cached_trace(p, stream='healthy')['metrics']
    f = replay_cached_trace(p, stream='injected')['metrics']
    return {'seed':seed, 'sha256':sha256(p.read_bytes()).hexdigest(),
            'methods':{m:{'fp':h[m]['false_alarms'], 'tp':f[m]['true_positives'],
                      'neighbor_fp':f[m]['unaffected_alerts']} for m in METHODS}}

def summarize(rows):
    n=len(rows)
    assert n==144 and [r['seed'] for r in rows]==list(range(1264,1408))
    rng=np.random.default_rng(350033)
    draw=rng.integers(n,size=(5000,n))
    out=dict(status='COMPLETE',research_only=True,independent_validation=False,
             note='Retrospective replay of previously viewed frozen v35 channel seeds 1264..1407; no tuning',
             completed=n,faulty_cases=2*n,healthy_cases=7*n,methods={},paired={})
    for m in METHODS:
        fp=np.array([r['methods'][m]['fp'] for r in rows]);tp=np.array([r['methods'][m]['tp'] for r in rows]);
        out['methods'][m]={'tp':int(tp.sum()),'recall':float(tp.sum()/(2*n)),
            'fp':int(fp.sum()),'far':float(fp.sum()/(7*n)),
            'neighbor_fp':int(sum(r['methods'][m]['neighbor_fp'] for r in rows)),
            'wilson_far_95':list(wilson(int(fp.sum()),7*n)),
            'cluster_far_95':np.quantile(fp[draw].sum(1)/(7*n),[.025,.975]).tolist(),
            'cluster_recall_95':np.quantile(tp[draw].sum(1)/(2*n),[.025,.975]).tolist()}
    for base in ('conservative_alert','sensitive_alert'):
        dt=np.array([r['methods']['hybrid_alert']['tp']-r['methods'][base]['tp'] for r in rows]);
        df=np.array([r['methods']['hybrid_alert']['fp']-r['methods'][base]['fp'] for r in rows]);
        out['paired']['hybrid_minus_'+base]={'extra_tp':int(dt.sum()),'extra_fp':int(df.sum()),
            'paired_recall_ci95':np.quantile(dt[draw].sum(1)/(2*n),[.025,.975]).tolist(),
            'paired_far_ci95':np.quantile(df[draw].sum(1)/(7*n),[.025,.975]).tolist()}
    out['reference_parity']={'v35':out['methods']['sensitive_alert']['tp']==274 and out['methods']['sensitive_alert']['fp']==42,
        'v33_scored_on_v35_cohort':out['methods']['conservative_alert']['tp']==253 and out['methods']['conservative_alert']['fp']==18}
    out['reference_parity_passed']=all(out['reference_parity'].values())
    return out

if __name__=='__main__':
    missing=[seed for seed in range(1264,1408) if not Path(f'/mnt/data/s{seed}.npz').exists()]
    if missing:raise RuntimeError(f'Missing archived traces: {missing}')
    rows=[]
    with ProcessPoolExecutor(max_workers=5) as pool:
        futures=[pool.submit(one,seed) for seed in range(1264,1408)]
        for i,fut in enumerate(as_completed(futures),1):
            rows.append(fut.result())
            if i%18==0:print(f'processed {i}/144',flush=True)
    rows.sort(key=lambda x:x['seed'])
    out=summarize(rows)
    Path('/mnt/data/SANAD_Hybrid_v33_v35_Retrospective_144_Results.json').write_text(json.dumps(out,indent=2))
    Path('/mnt/data/SANAD_Hybrid_v33_v35_Retrospective_144_Seed_Results.json').write_text(json.dumps(rows,indent=2))
    print('FINAL RESULTS:',json.dumps(out,indent=2),flush=True)
    if not out['reference_parity_passed']:
        raise RuntimeError('Historical model parity failed: do NOT trust hybrid benchmark')
