import unittest
from dataclasses import replace
import numpy as np
from sanad_v33 import EvidenceFusionV33,FusionConfigV33,ElementEvidence, _spatial_feature
from v33_study import DEV,TEST,candidate_configs

class Tests(unittest.TestCase):
    def setUp(self):
        self.cfg=FusionConfigV33()
    def run_evidence(self, fn, n=28, cfg=None):
        s=EvidenceFusionV33(cfg or self.cfg);rows=[]
        for t in range(n):
            data=fn(t)
            raw,names,fast,strict=data
            rows.append(s.step(raw,names,fast,strict))
        return rows
    def test_config_validation(self):
        for vals in ({'fast_hits':13},{'strict_hits':16},{'v11_hits':9},
                     {'fast_dominance':.9},{'strict_dominance':1.4},
                     {'corroboration_hits':15,'corroboration_window':12}):
            with self.subTest(vals=vals),self.assertRaises(ValueError):
                FusionConfigV33(**{**self.cfg.__dict__,**vals})
    def test_parallel_spatial_detection_without_v11_is_review_only(self):
        # v30 + v32 derive from the SAME signal and must not be counted as two independent votes.
        rows=self.run_evidence(lambda t:([False]*7,[0]*7,
            [ElementEvidence(1.2,2.1,4)]*7,[ElementEvidence(1.2,2.1,4)]*7))
        self.assertTrue(rows[-1][3].fast_v30)
        self.assertTrue(rows[-1][3].strict_v32)
        self.assertTrue(rows[-1][3].review_candidate)
        self.assertFalse(rows[-1][3].final_alert)
        self.assertEqual(rows[-1][3].antenna_1based,4)
    def test_repeated_v11_with_identity_is_alert(self):
        rows=self.run_evidence(lambda t:([t>=12]*7,[3 if t>=12 else 0]*7,[None]*7,[None]*7))
        self.assertTrue(rows[-1][1].confirmed_v11)
        self.assertTrue(rows[-1][1].final_alert)
        self.assertEqual(rows[-1][1].antenna_1based,3)
        self.assertEqual(rows[-1][1].action,'NO_HARDWARE_ACTUATION')
    def test_variable_v11_names_do_not_pass_identity(self):
        rows=self.run_evidence(lambda t:([t>=12]*7,[1+(t%8) if t>=12 else 0]*7,[None]*7,[None]*7))
        self.assertFalse(rows[-1][4].confirmed_v11)
        self.assertFalse(rows[-1][4].final_alert)
    def test_spatial_with_independent_style_v11_corroboration(self):
        rows=self.run_evidence(lambda t:([t in (14,18)]*7,[4 if t in (14,18) else 0]*7,
            [ElementEvidence(1.2,2.2,4)]*7,[ElementEvidence(1.2,2.2,4)]*7))
        self.assertTrue(rows[20][0].spatial_corroborated)
        self.assertFalse(rows[20][0].confirmed_v11)
        self.assertTrue(rows[20][0].final_alert)
    def test_spatial_corroboration_rejects_mismatched_antenna(self):
        rows=self.run_evidence(lambda t:([t in (14,18)]*7,[2 if t in (14,18) else 0]*7,
            [ElementEvidence(1.2,2.2,4)]*7,[ElementEvidence(1.2,2.2,4)]*7))
        self.assertFalse(rows[20][0].spatial_corroborated)
        self.assertFalse(rows[20][0].final_alert)
    def test_single_transient_v11_not_promoted(self):
        rows=self.run_evidence(lambda t:([t==17]*7,[2 if t==17 else 0]*7,
            [None]*7,[None]*7))
        self.assertFalse(any(row[0].final_alert for row in rows))
    def test_array_isolation(self):
        def f(t):
            raw=[False]*7;names=[0]*7
            raw[3]=t>9;names[3]=5 if t>9 else 0
            return raw,names,[None]*7,[None]*7
        rows=self.run_evidence(f)
        self.assertTrue(rows[-1][3].final_alert)
        self.assertFalse(any(rows[-1][a].final_alert for a in range(7) if a!=3))
    def test_spatial_feature_zero_prep(self):
        self.assertIsNone(_spatial_feature([]))
        self.assertIsNone(_spatial_feature([None]*12))
    def test_fresh_seed_partitions_no_overlap(self):
        self.assertEqual(len(DEV),24);self.assertEqual(len(TEST),144)
        self.assertEqual(DEV[0],888);self.assertEqual(TEST[-1],1055)
        self.assertFalse(set(DEV)&set(TEST))
        self.assertTrue(all(s>887 for s in DEV+TEST))
        self.assertEqual(len(candidate_configs()),8)
    def test_missing_identity_requires_corrob_name(self):
        rows=self.run_evidence(lambda t:([t in (12,15)]*7,[0]*7,
            [ElementEvidence(1.2,2.2,4)]*7,[ElementEvidence(1.2,2.2,4)]*7))
        self.assertFalse(rows[-1][4].final_alert)
    def test_bad_input_shape(self):
        with self.assertRaises(ValueError):EvidenceFusionV33().step([0]*6,[0]*7,[None]*7,[None]*7)

if __name__=='__main__':unittest.main()
