import json
from dataclasses import asdict
from pathlib import Path
import numpy as np
import pytest
from v35_study import DEV,TEST,PROTOCOL,source_hash,SOURCE_FILES,candidate_configs,summarize
from v35_replay import validate_v35_trace,replay_trace_v35
from sanad_v35 import FusionConfigV35
from qa_integrity import atomic_record


def test_partition_and_config_hash():
    assert DEV==tuple(range(1232,1264)) and TEST==tuple(range(1264,1408))
    assert not set(DEV)&set(TEST) and min(DEV)>1231
    assert len(candidate_configs())==10
    assert len(source_hash(Path(__file__).parent))==64
    assert all((Path(__file__).parent/f).exists() for f in SOURCE_FILES)


def fake_trace():
    t={}
    for stream in ('healthy','injected'):
        t[f'{stream}_v11']=np.zeros((300,7),dtype=np.uint8)
        t[f'{stream}_v11_named']=np.zeros((300,7),dtype=np.int8)
        t[f'{stream}_feats']=np.full((2,300,7,3),np.nan,dtype=np.float32)
        t[f'{stream}_delta']=np.full((300,7,3),np.nan,dtype=np.float32)
        t[f'{stream}_onset']=np.full(7,-1,dtype=np.int16)
        t[f'{stream}_expected']=np.full(7,-1,dtype=np.int8)
    t['injected_onset'][:2]=120;t['injected_expected'][:2]=3
    return t


def test_replay_schema_and_no_review_promotion():
    t=fake_trace()
    validate_v35_trace(t,'healthy')
    validate_v35_trace(t,'injected')
    o=replay_trace_v35(t,'healthy',FusionConfigV35())
    assert not o['final'].any()
    t['healthy_delta'][50,0]=[10,3,4]
    with pytest.raises(ValueError,match='noncausal baseline'):
        validate_v35_trace(t,'healthy')


def test_no_partial_qualification(tmp_path):
    r=summarize(tmp_path,TEST,FusionConfigV35(),'xyz',group='prospective')
    assert r['status']=='INCOMPLETE' and r['acceptance'] is None
    with pytest.raises(ValueError):summarize(tmp_path,DEV,FusionConfigV35(),'xyz',group='prospective')


def test_seal_and_reject_corruption(tmp_path):
    methods={m:dict(healthy_fp=0,fault_tp=2,post_onset_tp=2,neighbor_fp=0,
                    delay_reports=[10,11],terminal_named_correct=2,named_when_alerted=2)
             for m in ('v11','v30','v32','v33','v34','v35')}
    record=dict(seed=1264,group='prospective',source_sha256='xyz',protocol=PROTOCOL,
                config=asdict(FusionConfigV35()),methods=methods,
                review={k:0 for k in ('review_healthy','review_fault','review_only_healthy','review_only_fault',
                                        'cohort_review_healthy','cohort_review_fault')})
    p=tmp_path/'s1264.json';atomic_record(p,record)
    assert summarize(tmp_path,TEST,FusionConfigV35(),'xyz',group='prospective')['completed']==1
    z=json.loads(p.read_text());z['methods']['v35']['fault_tp']=0;p.write_text(json.dumps(z))
    with pytest.raises(ValueError,match='SHA-256'):
        summarize(tmp_path,TEST,FusionConfigV35(),'xyz',group='prospective')


def test_full_qualification_uses_v35_not_legacy(tmp_path):
    from v35_study import summarize
    conf=FusionConfigV35()
    zeros={k:0 for k in ('review_healthy','review_fault','review_only_healthy','review_only_fault',
                          'cohort_review_healthy','cohort_review_fault')}
    for seed in TEST:
        meth={}
        for name in ('v11','v30','v32','v33','v34','v35'):
            tp=2 if name=='v35' else 1
            meth[name]=dict(healthy_fp=0,fault_tp=tp,post_onset_tp=tp,
                            neighbor_fp=0,delay_reports=[10]*tp,
                            terminal_named_correct=tp,named_when_alerted=tp)
        atomic_record(tmp_path/f's{seed}.json',dict(seed=seed,group='prospective',
                     source_sha256='h',protocol=PROTOCOL,config=asdict(conf),
                     methods=meth,review=zeros))
    result=summarize(tmp_path,TEST,conf,'h',group='prospective',boots=300)
    assert result['status']=='COMPLETE' and result['acceptance']['passed']
    assert result['methods']['v35']['fault_tp']==288
    assert result['methods']['v34']['fault_tp']==144
