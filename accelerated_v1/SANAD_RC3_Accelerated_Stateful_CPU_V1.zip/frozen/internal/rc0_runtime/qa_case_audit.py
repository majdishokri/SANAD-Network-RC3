"""Read-only v34 development case audit. NEVER a validation or tuning gate.

Consumes prior-development Sionna *proxy evidence* only, never future v35
qualification seeds. Reports reason codes without tuning thresholds on outcomes.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import asdict
from pathlib import Path
import json
import numpy as np
from sanad_v34 import FusionConfigV34
from v34_replay import replay_trace
from qa_integrity import validate_trace

DEV=tuple(range(1056,1088))


def audit_development(cache, selection, *, output=None):
    cache=Path(cache)
    selected=json.loads(Path(selection).read_text())
    if (selected.get('development_seeds')!=list(DEV) or
        selected.get('status')!='COMPLETE' or
        selected.get('protocol')!='V34_MODULAR_RF_FUSION_DEV_1056_1087_TEST_1088_1231_RC0'):
        raise ValueError('Not the original 32-seed v34 development selection')
    cfg=FusionConfigV34(**selected['selected']['config'])
    counters=Counter();cases=[]
    for seed in DEV:
        p=cache/f's{seed}.npz'
        if not p.is_file():raise FileNotFoundError(str(p))
        with np.load(p,allow_pickle=False) as z:
            trace=dict(z)
        for stream in ('healthy','injected'):
            validate_trace(trace,stream)
            out=replay_trace(trace,stream,cfg)
            if stream=='healthy':
                for a in range(7):
                    if out['final'][260:,a].any():
                        counters['healthy_primary_false_alarms']+=1
                        cases.append(dict(seed=seed,stream=stream,array=a,
                                          event='false_alarm',v11=bool(out['v11'][260:,a].any()),
                                          spatial_quality=bool(out['quality'][260:,a].any()),
                                          fast=bool(out['fast'][260:,a].any()),
                                          strict=bool(out['strict'][260:,a].any())))
            else:
                for a in range(7):
                    if trace['injected_expected'][a] <= 0:continue
                    counters['faults']+=1
                    found=bool(out['final'][260:,a].any())
                    counters['primary_detected' if found else 'primary_missed']+=1
                    if found:continue
                    evidence={key:bool(out[key][260:,a].any()) for key in ('fast','strict','v11','quality','agreement','review','cohort')}
                    reason=('NO_PERSISTENT_UPSTREAM_EVIDENCE' if not any(evidence[k] for k in ('fast','strict','v11'))
                            else 'FAST_ONLY' if evidence['fast'] and not evidence['strict'] and not evidence['v11']
                            else 'STRICT_ONLY' if evidence['strict'] and not evidence['v11']
                            else 'FUSION_NOT_PROMOTED')
                    counters['miss_reason_'+reason]+=1
                    cases.append(dict(seed=seed,stream=stream,array=a,
                                      event='missed_fault',reason=reason,
                                      expected_antenna=int(trace['injected_expected'][a]),
                                      onset_report=int(trace['injected_onset'][a]),
                                      **evidence))
    result=dict(research_only=True,source='ORIGINAL_v34_DEVELOPMENT_1056_1087',
                decision_config=asdict(cfg),counts=dict(counters),cases=cases,
                caveat=('Exploratory development case audit. Do not treat this as independent validation; '
                         'never tune a new version using v34 prospective seeds 1088–1231.'))
    if output:
        Path(output).parent.mkdir(parents=True,exist_ok=True)
        Path(output).write_text(json.dumps(result,indent=2,sort_keys=True))
    return result

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--cache',required=True)
    ap.add_argument('--selection',required=True);ap.add_argument('--output',required=True)
    args=ap.parse_args()
    r=audit_development(args.cache,args.selection,output=args.output)
    print(json.dumps(r['counts'],indent=2,sort_keys=True))
