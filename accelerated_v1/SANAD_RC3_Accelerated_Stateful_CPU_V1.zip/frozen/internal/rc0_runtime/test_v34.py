import unittest
from dataclasses import replace
import numpy as np
from sanad_v34 import EvidenceFusionV34, FusionConfigV34, ElementEvidence
from v34_replay import replay_trace

E=ElementEvidence(1.5,2.6,3)
LOW=ElementEvidence(.91,1.9,3)

def scenario(steps=25, *,raw=False,name=0,fast=E,strict=E,valid=True):
    engine=EvidenceFusionV34()
    out=[]
    for t in range(steps):
        raws=[raw]*7;names=[name]*7
        fs=[None]*7;ss=[None]*7;good=[True]*7
        fs[2]=fast;ss[2]=strict;raws[2]=raw;names[2]=name
        good[2]=valid
        out.append(engine.step(raws,names,fs,ss,good))
    return out

class Tests(unittest.TestCase):
    def test_version_component_boundaries(self):
        c=FusionConfigV34()
        assert (c.fast_hits,c.fast_window,c.fast_dominance)==(8,12,1.5)
        assert (c.strict_hits,c.strict_window,c.strict_dominance)==(10,15,1.8)
        assert (c.v11_hits,c.v11_window,c.v11_identity_hits)==(5,8,3)

    def test_v34_can_promote_strong_spatial_without_v11(self):
        d=scenario()[-1][2]
        assert d.final_alert and d.spatial_quality and d.spatial_correlated_agreement
        assert not d.supported_by_v11 and not d.raw_v11
        assert d.antenna_1based==3 and d.antenna_source=='spatial_quality_correlated'
        assert d.action=='NO_HARDWARE_ACTUATION'

    def test_raw_spatial_weak_alone_is_review_only(self):
        d=scenario(fast=LOW,strict=LOW)[-1][2]
        assert d.review_candidate and d.review_only and not d.final_alert
        assert d.v30_fast and d.v32_strict and not d.spatial_quality

    def test_v11_only_recovers_anchored_alert(self):
        d=scenario(raw=True,name=5,fast=None,strict=None)[-1][2]
        assert d.final_alert and d.v11_persistent and d.antenna_1based==5
        assert d.antenna_source=='v11_repeated_identity'

    def test_partial_v11_rescues_moderate_spatial_same_name(self):
        model=EvidenceFusionV34()
        for t in range(25):
            raw=[False]*7;names=[0]*7;fast=[None]*7;strict=[None]*7
            if t in (14,18):raw[2]=True;names[2]=3
            fast[2]=LOW;strict[2]=LOW
            d=model.step(raw,names,fast,strict)[2]
        assert d.final_alert and d.supported_by_v11 and not d.v11_persistent
        assert d.antenna_1based==3

    def test_partial_v11_different_antenna_not_rescue(self):
        model=EvidenceFusionV34()
        for t in range(25):
            raw=[False]*7;names=[0]*7;fast=[None]*7;strict=[None]*7
            if t in (14,18):raw[2]=True;names[2]=5
            fast[2]=LOW;strict[2]=LOW
            d=model.step(raw,names,fast,strict)[2]
        assert not d.final_alert and d.review_only

    def test_spatial_identity_mismatch_not_promoted(self):
        d=scenario(fast=ElementEvidence(1.5,2.6,3),strict=ElementEvidence(1.6,2.6,4))[-1][2]
        assert d.v30_fast and d.v32_strict
        assert not d.spatial_correlated_agreement and not d.final_alert

    def test_network_wide_cohort_ambiguous_spatial_becomes_review(self):
        m=EvidenceFusionV34()
        for t in range(26):
            features=[E]*4 + [None]*3
            d=m.step([False]*7,[0]*7,features,features)
        assert all(d[a].cohort_ambiguous and d[a].review_only and not d[a].final_alert for a in range(4))
        assert all(not d[a].final_alert for a in range(4,7))

    def test_cohort_gate_does_not_veto_stable_v11(self):
        m=EvidenceFusionV34()
        for t in range(26):
            features=[E]*4+[None]*3
            raw=[False]*7;names=[0]*7;raw[0]=True;names[0]=3
            d=m.step(raw,names,features,features)
        assert d[0].final_alert and d[0].v11_persistent
        assert all(d[a].review_only for a in (1,2,3))

    def test_invalid_gates_do_not_issue_final_alert(self):
        m=EvidenceFusionV34()
        for t in range(25):
            raw=[False]*7;names=[0]*7;fast=[None]*7;strict=[None]*7
            raw[2]=True;names[2]=3;fast[2]=E;strict[2]=E
            m.step(raw,names,fast,strict)
        raw=[False]*7;names=[0]*7;fast=[None]*7;strict=[None]*7
        raw[2]=True;names[2]=3;fast[2]=E;strict[2]=E
        good=[True]*7;good[2]=False
        d=m.step(raw,names,fast,strict,good)[2]
        assert not d.final_alert and d.status=='INSUFFICIENT_MEASUREMENTS'

    def test_single_raw_pulse_is_not_confirmation(self):
        m=EvidenceFusionV34()
        for t in range(25):
            raw=[False]*7;names=[0]*7
            if t==16:raw[2]=True;names[2]=3
            d=m.step(raw,names,[None]*7,[None]*7)[2]
            assert not d.final_alert

    def test_array_isolation(self):
        out=scenario()[-1]
        assert out[2].final_alert and not any(x.final_alert for i,x in enumerate(out) if i!=2)

    def test_bad_configuration(self):
        for k,v in [('fast_hits',13),('strict_hits',16),('v11_hits',9),
                    ('quality_hits',16),('quality_score_multiple',.8),
                    ('quality_dominance',1.5),('cohort_review_at',9),
                    ('partial_v11_hits',13)]:
            with self.subTest(k=k),self.assertRaises(ValueError):
                replace(FusionConfigV34(),**{k:v})

    def test_bad_shape_and_identity(self):
        with self.assertRaises(ValueError):EvidenceFusionV34().step([False]*6,[0]*7,[None]*7,[None]*7)
        with self.assertRaises(ValueError):EvidenceFusionV34().step([False]*7,[9]*7,[None]*7,[None]*7)

    def test_replay_matches_pure_engine_all_300x7(self):
        rng=np.random.default_rng(34012)
        trace={}
        raw=(rng.random((300,7))<.16).astype(np.uint8)
        named=np.where(raw>0,rng.integers(1,9,size=(300,7)),0).astype(np.int8)
        feats=np.zeros((2,300,7,3),np.float32)
        feats[:,:,:,0]=rng.uniform(.45,1.7,size=(2,300,7))
        feats[:,:,:,1]=rng.uniform(1.3,2.8,size=(2,300,7))
        feats[:,:,:,2]=rng.integers(1,9,size=(2,300,7))
        for label in ('healthy','injected'):
            trace[f'{label}_v11']=raw
            trace[f'{label}_v11_named']=named
            trace[f'{label}_feats']=feats
        actual=replay_trace(trace,'injected',FusionConfigV34())
        direct=EvidenceFusionV34()
        for t in range(300):
            evid=[]
            for w in (0,1):
                evid.append([ElementEvidence(*[float(z) for z in feats[w,t,a]]) for a in range(7)])
            row=direct.step(raw[t].tolist(),named[t].tolist(),evid[0],evid[1])
            for a,x in enumerate(row):
                assert actual['final'][t,a]==x.final_alert
                assert actual['review'][t,a]==x.review_candidate
                assert actual['antenna'][t,a]==(x.antenna_1based or 0)
                assert x.action=='NO_HARDWARE_ACTUATION'

    def test_replay_equals_direct_engine_no_lookahead(self):
        trace={}
        for prefix in ('healthy','injected'):
            raw=np.zeros((300,7),np.uint8);named=np.zeros((300,7),np.int8)
            feat=np.full((2,300,7,3),np.nan,np.float32)
            raw[220:250,2]=1;named[220:250,2]=3
            feat[:,150:,2,:]=np.array([1.5,2.6,3],np.float32)
            trace[f'{prefix}_v11']=raw
            trace[f'{prefix}_v11_named']=named
            trace[f'{prefix}_feats']=feat
        out=replay_trace(trace,'healthy',FusionConfigV34())
        assert not out['final'][:150].any()
        assert out['final'][260:,2].any()
        assert not out['final'][:,[0,1,3,4,5,6]].any()
        assert out['antenna'][-1,2]==3

if __name__=='__main__':unittest.main()
