"""Single-source causal replay for SANAD v33.

Uses the SAME EvidenceFusionV33.step as the live SANADNetworkV33 wrapper.
Never uses simulator fault labels in inference; labels are read by study.py only.
"""
from __future__ import annotations
import numpy as np
from sanad_v33 import EvidenceFusionV33, ElementEvidence, FusionConfigV33


def replay_trace(trace:dict, stream:str, config:FusionConfigV33):
    if stream not in ('healthy','injected'):raise ValueError('Invalid stream')
    raw=np.asarray(trace[f'{stream}_v11'])
    named=np.asarray(trace[f'{stream}_v11_named'])
    feats=np.asarray(trace[f'{stream}_feats'])
    if raw.shape!=(300,7) or named.shape!=(300,7) or feats.shape!=(2,300,7,3):
        raise ValueError('Invalid frozen evidence shape')
    f=EvidenceFusionV33(config)
    flags={k:np.zeros((300,7),bool) for k in
           ('final','review','review_only','fast','strict','confirmed_v11','corroborated')}
    ant=np.zeros((300,7),np.int8)
    status=np.empty((300,7),dtype='<U42')
    for t in range(300):
        items=[]
        for wi in range(2):
            win=[]
            for a in range(7):
                s,d,e=feats[wi,t,a]
                win.append(ElementEvidence(float(s),float(d),int(e)) if np.isfinite(s) and np.isfinite(d) and np.isfinite(e) else None)
            items.append(win)
        out=f.step(raw[t].tolist(),named[t].tolist(),items[0],items[1],
                   [bool(np.isfinite(feats[:,t,a,0]).any()) for a in range(7)])
        for a,x in enumerate(out):
            flags['final'][t,a]=x.final_alert
            flags['review'][t,a]=x.review_candidate
            flags['review_only'][t,a]=x.review_only
            flags['fast'][t,a]=x.fast_v30
            flags['strict'][t,a]=x.strict_v32
            flags['confirmed_v11'][t,a]=x.confirmed_v11
            flags['corroborated'][t,a]=x.spatial_corroborated
            ant[t,a]=x.antenna_1based or 0
            status[t,a]=x.status
    return {**flags,'antenna':ant,'status':status}
