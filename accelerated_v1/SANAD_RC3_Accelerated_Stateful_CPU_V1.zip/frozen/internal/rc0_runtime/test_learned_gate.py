from pathlib import Path
import numpy as np
import pytest
from inference_v35_gate import FrozenV35LearnedGate
from feature_engineering import features_per_array

BASE=Path(__file__).parent

def test_frozen_model_exists_and_sources():
 model=FrozenV35LearnedGate()
 assert abs(model.threshold-0.18)<1e-12
 assert model.bundle['frozen_v35_config']=='legacy_union'
 assert len(model.bundle['names'])>50
 assert model.bundle['action']=='NO_HARDWARE_ACTUATION'

@pytest.mark.skipif(not Path('/mnt/data/s1264.npz').exists(),reason='Local archived source not mounted')
def test_model_replay_is_deterministic_and_no_injection_truth_used():
 with np.load('/mnt/data/s1264.npz',allow_pickle=False) as f:trace=dict(f)
 model=FrozenV35LearnedGate()
 for stream in ('healthy','injected'):
  pred1=model.predict_trace(trace,stream)
  assert len(pred1)==7
  assert all(0<=p.probability<=1 for p in pred1)
  assert all(p.action=='NO_HARDWARE_ACTUATION' for p in pred1)
  altered=dict(trace)
  altered[f'{stream}_expected']=np.full(7,127,dtype=np.int8)
  altered[f'{stream}_onset']=np.full(7,127,dtype=np.int16)
  pred2=model.predict_trace(altered,stream)
  for a,b in zip(pred1,pred2):
   assert a.array_id==b.array_id and a.v35_candidate==b.v35_candidate and a.learned_confirmed_alert==b.learned_confirmed_alert
   assert np.isclose(a.probability,b.probability,rtol=1e-11,atol=1e-12)

@pytest.mark.skipif(not Path('/mnt/data/s1264.npz').exists(),reason='Local archived source not mounted')
def test_bad_feature_rejected():
 with np.load('/mnt/data/s1264.npz',allow_pickle=False) as f:trace=dict(f)
 x,names=features_per_array(trace,'healthy')
 m=FrozenV35LearnedGate()
 with pytest.raises(ValueError):m.predict_features(x[:6],names)
 with pytest.raises(ValueError):m.predict_features(np.full_like(x,np.nan),names)
 with pytest.raises(ValueError):m.predict_features(x,names[:-1])
