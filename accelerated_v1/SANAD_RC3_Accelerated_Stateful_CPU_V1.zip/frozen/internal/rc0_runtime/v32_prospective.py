"""No-retuning prospective qualification for SANAD v32 on fresh Sionna 744..887.

144 independent RF channel seeds, 1008 healthy array cases, 288 faulty cases.
Strict separation from failed v31 seeds 600..743. Research-only.
"""
from __future__ import annotations
import argparse, hashlib, json, os, tempfile
from pathlib import Path
import numpy as np
from qualification import validate_covariance, wilson
from v32_replay import extract_seed, gate_evidence
from sanad_v32 import FusionConfig

FRESH=tuple(range(744,888))
PROTOCOL='V32_FROZEN_EVIDENCE_FUSION_FRESH_SIONNA_744_887'
BASELINE_CONFIG=FusionConfig(score_threshold=0.7687096042171566,dominance_ratio=1.5,
                             persistence=8,recent=12,v11_confirm_min=1,v11_confirm_window=1,
                             v11_identity_min=0)
SOURCE=['sanad_v32.py','v32_replay.py','v32_prospective.py','sanad_v29.py','v29_research.py',
        'detect_v11.py','monitor_v8.py','glr_compare.py','sionna_gen.py','qualification.py','config_frozen.json']


def sha256_file(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()


def frozen_source_hash(src_dir):
 h=hashlib.sha256()
 for name in SOURCE:
  p=Path(src_dir)/name
  h.update(name.encode()+b'\0'+bytes.fromhex(sha256_file(p)))
 return h.hexdigest()


def write_json_atomic(dest, obj):
 dest=Path(dest);dest.parent.mkdir(parents=True,exist_ok=True)
 with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=dest.parent,prefix=dest.stem,suffix='.tmp',delete=False) as f:
  json.dump(obj,f,indent=2);tmp=f.name
 os.replace(tmp,dest)


def _metric_counts(trace,cfg):
 ret={m:dict(healthy_fp=0,fault_tp=0,post_onset_tp=0,neighbor_fp=0,delay_reports=[],
             named_correct=0,named_when_alerted=0) for m in ('v11','v30','v32')}
 for stream in ('healthy','injected'):
  raw=trace[f'{stream}_v11'].astype(bool)
  raw_name=trace[f'{stream}_v11_named']
  feat=trace[f'{stream}_feats']
  expected=trace[f'{stream}_expected']
  onset=trace[f'{stream}_onset']
  base30,_,base_cand=gate_evidence(raw,feat,BASELINE_CONFIG,raw_named=raw_name)
  output32,_,cand32=gate_evidence(raw,feat,cfg,raw_named=raw_name)
  flags={'v11':raw,'v30':base30,'v32':output32}
  for m,flag in flags.items():
   for a in range(7):
    has=bool(flag[260:,a].any())
    if stream=='healthy':ret[m]['healthy_fp']+=int(has)
    elif expected[a]>0:
     ret[m]['fault_tp']+=int(has)
     on=int(onset[a]); after=np.flatnonzero(flag[on:,a]);hit=bool(len(after))
     ret[m]['post_onset_tp']+=int(hit)
     if hit:ret[m]['delay_reports'].append(int(after[0]))
     # Terminal estimate on final report, not necessarily when decision first fired.
     if m=='v11':nm=int(raw_name[-1,a]) if raw[-1,a] else 0
     elif m=='v30':
      nm=int(raw_name[-1,a]) if raw[-1,a] else 0
      if nm<=0 and base_cand[-1,a]:
       nm=int(feat[0,-1,a,2]) if np.isfinite(feat[0,-1,a,2]) else 0
     else:
      # Causal identity: if current report has v11 antenna use it; otherwise
      # use modal recent v11 identity, then strongest spatial candidate.
      nm=int(raw_name[-1,a]) if raw[-1,a] else 0
      if nm<=0:
       recent=raw_name[max(0,len(raw)-cfg.v11_confirm_window):,a]
       recent=recent[recent>0]
       if len(recent):nm=int(np.bincount(recent).argmax())
      if nm<=0 and cand32[-1,a]:
       wi=0 if cfg.recent==12 else 1
       nm=int(feat[wi,-1,a,2]) if np.isfinite(feat[wi,-1,a,2]) else 0
     good=int(nm==int(expected[a]))
     ret[m]['named_correct']+=good
     if has:ret[m]['named_when_alerted']+=good
    else:ret[m]['neighbor_fp']+=int(has)
 return ret


def evaluate_seed(seed, cov_dir, cache_dir, result_dir, src_dir, cfg, expected_hash):
 if seed not in FRESH:raise ValueError('Only seeds 744..887 are allowed for new prospective run')
 result_dir=Path(result_dir);dest=result_dir/f's{seed}.json'
 if dest.exists():
  old=json.loads(dest.read_text())
  if old.get('source_sha256')!=expected_hash or old.get('protocol')!=PROTOCOL:
   raise ValueError(f'Frozen source mismatch for existing {seed}: refuse silently mixing results')
  return old
 npz=Path(cov_dir)/f's{seed}.npz'
 if not npz.exists():raise FileNotFoundError(f'Covariance missing: {npz} — generate it with Sionna 2.2.0')
 cache=Path(cache_dir)/f's{seed}.npz'
 if not cache.exists():extract_seed(npz,src_dir,seed,cache)
 with np.load(cache,allow_pickle=False) as z:trace=dict(z)
 r=dict(protocol=PROTOCOL,seed=seed,source_sha256=expected_hash,
        covariance_sha256=sha256_file(npz),rows=_metric_counts(trace,cfg),
        calibration_proxy=True,simulation_not_field=True)
 write_json_atomic(dest,r)
 return r


def summarize(result_dir,cfg,expected_hash,boots=3000):
 rows={}
 for sd in FRESH:
  p=Path(result_dir)/f's{sd}.json'
  if not p.exists():continue
  r=json.loads(p.read_text())
  if r.get('source_sha256')!=expected_hash or r.get('protocol')!=PROTOCOL or r.get('seed')!=sd:
   raise ValueError(f'Invalid or changed result file: {p}')
  rows[sd]=r['rows']
 out=dict(status='COMPLETE' if len(rows)==len(FRESH) else 'INCOMPLETE',
          seed_count=len(rows),required_seeds=len(FRESH),protocol=PROTOCOL,
          source_sha256=expected_hash,config=cfg.__dict__,methods={},qualification=None,
          limitations=['Synthetic 3GPP UMa channel proxy, not real antenna RF telemetry',
                       'Seven arrays within each seed are correlated',
                       'The v32 score and fusion gate MUST remain frozen throughout this study',
                       'Outputs are research reviews/advisories, never RF hardware actuation'])
 if not rows:return out
 for m in ('v11','v30','v32'):
  def total(key):return int(sum(r[m][key] for r in rows.values()))
  fp=total('healthy_fp');tp=total('fault_tp');nt=total('post_onset_tp')
  n=len(rows)
  dl=[v for r in rows.values() for v in r[m]['delay_reports']]
  out['methods'][m]=dict(healthy_false_alarms=fp,healthy_cases=7*n,
         false_alarm_rate=fp/(7*n),ci95_wilson_false_alarm=wilson(fp,7*n),
         fault_true_positives=tp,fault_cases=2*n,recall=tp/(2*n),
         recall_ci95_wilson=wilson(tp,2*n),
         post_onset_tp=nt,neighbor_false_alarms=total('neighbor_fp'),
         median_delay_hours=float(np.median(dl)/4) if dl else None,
         terminal_named_correct=total('named_correct'))
 if n>=2 and boots:
  ids=list(rows)
  rng=np.random.default_rng(41236)
  draw=rng.integers(0,n,size=(boots,n))
  for m in ('v11','v30','v32'):
   f=np.asarray([rows[s][m]['healthy_fp'] for s in ids]);tp=np.asarray([rows[s][m]['fault_tp'] for s in ids])
   out['methods'][m]['cluster_false_alarm_ci95']=np.quantile(f[draw].sum(axis=1)/(7*n),[.025,.975]).tolist()
   out['methods'][m]['cluster_recall_ci95']=np.quantile(tp[draw].sum(axis=1)/(2*n),[.025,.975]).tolist()
  for base in ('v11','v30'):
   delta=np.asarray([rows[s]['v32']['fault_tp']-rows[s][base]['fault_tp'] for s in ids])
   out[f'v32_recall_gain_vs_{base}_seed_cluster_ci95']=np.quantile(delta[draw].sum(axis=1)/(2*n),[.025,.975]).tolist()
 if n==len(FRESH):
  v=out['methods']['v32'];u=v['ci95_wilson_false_alarm'][1];cu=v['cluster_false_alarm_ci95'][1]
  recgain=out['v32_recall_gain_vs_v11_seed_cluster_ci95'][0]
  out['qualification']=dict(gate_pass=bool(u<.02 and cu<.02 and recgain>0 and v['recall']>=.9),
     wilson_false_upper=u,cluster_false_upper=cu,paired_recall_gain_lower_v11=recgain,
     recall_point=v['recall'],rule='Both false upper bounds below 2%, v32 recall >=90%, paired v32-v11 lower gain >0')
 return out


def main():
 p=argparse.ArgumentParser()
 p.add_argument('--src-dir',default='.')
 p.add_argument('--cov-dir',required=True)
 p.add_argument('--cache-dir',required=True)
 p.add_argument('--results-dir',required=True)
 p.add_argument('--max-seeds',type=int,default=144)
 args=p.parse_args()
 src=Path(args.src_dir).resolve();cfg=FusionConfig(**json.loads((src/'config_frozen.json').read_text()))
 expected_hash=frozen_source_hash(src)
 p=Path(args.results_dir);p.mkdir(parents=True,exist_ok=True)
 manifest=p/'manifest.json'
 if manifest.exists():
  old=json.loads(manifest.read_text())
  if old['source_sha256']!=expected_hash:raise RuntimeError('Source changed: new folder needed')
 else:write_json_atomic(manifest,dict(protocol=PROTOCOL,source_sha256=expected_hash,config=cfg.__dict__,seeds=list(FRESH)))
 for seed in FRESH[:args.max_seeds]:
  if not (p/f's{seed}.json').exists():
   evaluate_seed(seed,args.cov_dir,args.cache_dir,p,src,cfg,expected_hash)
   print(f'Completed seed {seed}',flush=True)
  report=summarize(p,cfg,expected_hash,boots=1000)
  write_json_atomic(p/'summary.json',report)
 print(json.dumps({k:report.get(k) for k in ('status','seed_count','qualification')},indent=2),flush=True)

if __name__=='__main__':main()
