"""Negative and process tests for the QA-only v34 hardening patch."""
from __future__ import annotations
import copy
import io
import json
import stat
import zipfile
from pathlib import Path
import numpy as np
import pytest
from qa_integrity import validate_trace,atomic_record,read_record,safe_extract_source
from sanad_v34 import EvidenceFusionV34
from v34_replay import replay_trace


def fixture_trace():
    d={}
    for name in ('healthy','injected'):
        d[f'{name}_v11']=np.zeros((300,7),dtype=np.uint8)
        d[f'{name}_v11_named']=np.zeros((300,7),dtype=np.int8)
        d[f'{name}_feats']=np.full((2,300,7,3),np.nan,dtype=np.float32)
        d[f'{name}_onset']=np.full(7,-1,dtype=np.int16)
        d[f'{name}_expected']=np.full(7,-1,dtype=np.int8)
    d['injected_onset'][1]=127
    d['injected_onset'][4]=130
    d['injected_expected'][1]=3
    d['injected_expected'][4]=5
    return d


def test_valid_traces():
    d=fixture_trace()
    for s in ('healthy','injected'):validate_trace(d,s)
    replay_trace(d,'healthy',__import__('sanad_v34').FusionConfigV34())


@pytest.mark.parametrize('field,modify',[
    ('healthy_v11',lambda x:x.__setitem__((20,2),2)),
    ('healthy_v11_named',lambda x:x.__setitem__((20,2),9)),
    ('healthy_feats',lambda x:x.__setitem__((0,20,2,0),1.2)),
    ('healthy_onset',lambda x:x.__setitem__(2,15)),
    ('injected_expected',lambda x:x.__setitem__(1,-1)),
])
def test_malformed_trace_rejected(field,modify):
    d=fixture_trace();modify(d[field])
    with pytest.raises(ValueError):validate_trace(d,'healthy' if field.startswith('healthy') else 'injected')


def test_nan_alert_and_validity_rejected():
    m=EvidenceFusionV34()
    args=([False]*7,[0]*7,[None]*7,[None]*7)
    raw=[False]*7;raw[0]=float('nan')
    with pytest.raises(ValueError,match='Invalid v11'):m.step(raw,*args[1:])
    valid=[True]*7;valid[1]=float('nan')
    with pytest.raises(ValueError,match='Invalid sample-valid'):m.step(*args,valid)


def test_record_seal_detects_tampering(tmp_path):
    f=tmp_path/'record.json'
    atomic_record(f,{'seed':1232,'metrics':{'fault_tp':2}})
    assert read_record(f)['seed']==1232
    data=json.loads(f.read_text());data['metrics']['fault_tp']=0
    f.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='SHA-256 mismatch'):read_record(f)


def test_missing_record_digest_rejected(tmp_path):
    f=tmp_path/'legacy.json';f.write_text('{}')
    with pytest.raises(ValueError,match='missing'):read_record(f)


@pytest.mark.parametrize('member', ['../escape.py','../../hack','/absolute.py','folder/x.py','bad\\x.py'])
def test_zip_path_traversal_rejected(member,tmp_path):
    archive=tmp_path/'unsafe.zip'
    with zipfile.ZipFile(archive,'w') as z:z.writestr(member,b'X')
    with pytest.raises(ValueError):safe_extract_source(archive,tmp_path/'dest')


def test_zip_duplicate_rejected(tmp_path):
    archive=tmp_path/'dupe.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('file.py',b'a')
        z.writestr('file.py',b'b')
    with pytest.raises(ValueError):safe_extract_source(archive,tmp_path/'dest')


def test_zip_symlink_rejected(tmp_path):
    archive=tmp_path/'link.zip'
    member=zipfile.ZipInfo('link.py');member.create_system=3
    member.external_attr=(stat.S_IFLNK|0o777)<<16
    with zipfile.ZipFile(archive,'w') as z:z.writestr(member,b'/etc/passwd')
    with pytest.raises(ValueError,match='Symlink'):safe_extract_source(archive,tmp_path/'dest')


def test_zip_safe_extract(tmp_path):
    archive=tmp_path/'good.zip'
    with zipfile.ZipFile(archive,'w') as z:z.writestr('hello.py',b'print(1)\n')
    assert safe_extract_source(archive,tmp_path/'src')==['hello.py']
    assert (tmp_path/'src'/'hello.py').read_text()=='print(1)\n'


def test_archive_rejects_excessive_member_size(tmp_path):
    archive=tmp_path/'huge.zip'
    with zipfile.ZipFile(archive,'w') as z:z.writestr('big.py',b'a'*500)
    with pytest.raises(ValueError,match='size limit'):safe_extract_source(archive,tmp_path/'x',max_member=100)
