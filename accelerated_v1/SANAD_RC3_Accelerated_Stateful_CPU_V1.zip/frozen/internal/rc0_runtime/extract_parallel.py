"""Parallel extraction from saved, already-inspected v35 prospective traces."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import os,time,argparse
import numpy as np
from feature_engineering import extract_dataset

def one(seed):
 return seed,extract_dataset([f'/mnt/data/s{seed}.npz'])

def main():
 p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=1264);p.add_argument('--stop',type=int,default=1408);p.add_argument('--workers',type=int,default=5);p.add_argument('--out',default='/mnt/data/SANAD_V35_Learned_Gate_Research/historical_features.npz');a=p.parse_args()
 expected=set(range(a.start,a.stop));outputs={};t0=time.monotonic()
 with ProcessPoolExecutor(max_workers=a.workers) as pool:
  futures=[pool.submit(one,s) for s in sorted(expected)]
  for i,fut in enumerate(as_completed(futures),1):
   k,v=fut.result();outputs[k]=v
   if i%12==0: print('extract',i,'/',len(expected),'elapsed',round(time.monotonic()-t0,1),flush=True)
 if set(outputs)!=expected:raise RuntimeError('missing seeds')
 keys=('X','y','seed','stream','array','case_sha');cols=outputs[a.start]['columns']
 if any(outputs[s]['columns']!=cols for s in outputs):raise RuntimeError('schema mismatch')
 joined={k:np.concatenate([outputs[s][k] for s in sorted(outputs)],axis=0) for k in keys}
 assert len(joined['X'])==len(expected)*14 and joined['y'].sum()==len(expected)*2
 np.savez_compressed(a.out,**joined,columns=np.array(cols,dtype='<U100'))
 print('COMPLETE',len(expected),'seeds',len(joined['X']),'rows','seconds',round(time.monotonic()-t0,1),flush=True)

if __name__=='__main__':main()
