import json
from pathlib import Path
import numpy as np
import pytest
from sanad_v33 import FusionConfigV33
from v33_study import (DEV,TEST,PROTOCOL,atomic_json,summarize_run,
                      candidate_configs,score_configs,evaluate_seed)


def _case(seed,group,sha,cfg,fp=0,tp=2,oldtp=1):
    row={}
    for m in ('v11','v30','v32','v33'):
        hit=oldtp if m=='v11' else tp
        row[m]={'healthy_fp':fp if m=='v33' else 0,
                'fault_tp':hit,'post_onset_tp':hit,'neighbor_fp':0,
                'delay_reports':[18]*hit,'terminal_named_correct':hit,
                'named_when_alerted':hit}
    return {'seed':seed,'group':group,'source_sha256':sha,'protocol':PROTOCOL,
            'config':cfg.__dict__,'methods':row,
            'review':dict(review_healthy=0,review_fault=2,review_only_healthy=0,
                          review_only_fault=1,spatial_confirmed_fault=1,v11_confirmed_fault=1)}


def test_fresh_groups_no_leakage():
    assert DEV==tuple(range(888,912)) and TEST==tuple(range(912,1056))
    assert set(DEV).isdisjoint(TEST)
    assert all(x<888 or x>1055 for x in (512,743,744,887))
    with pytest.raises(ValueError):evaluate_seed(744,'prospective','x','y','z','u','h',FusionConfigV33())
    with pytest.raises(ValueError):evaluate_seed(912,'development','x','y','z','u','h',FusionConfigV33())


def test_partial_is_never_qualified(tmp_path):
    cfg=FusionConfigV33();sha='dummy'
    atomic_json(tmp_path/'s912.json',_case(912,'prospective',sha,cfg))
    a=summarize_run(tmp_path,TEST,cfg,sha,group='prospective',boots=10)
    assert a['status']=='INCOMPLETE' and a['acceptance'] is None
    assert a['completed']==1


def test_complete_pass_and_false_bound_failure(tmp_path):
    cfg=FusionConfigV33();sha='dummy'
    for sd in TEST:atomic_json(tmp_path/f's{sd}.json',_case(sd,'prospective',sha,cfg))
    success=summarize_run(tmp_path,TEST,cfg,sha,group='prospective',boots=200)
    assert success['status']=='COMPLETE' and success['acceptance']['passed']
    # Invalid even when the healthy FP point estimate is below 2%:
    # 11 failures trigger a wider cluster bound if concentrated in one seed.
    one=tmp_path/'s912.json';obj=json.loads(one.read_text());obj['methods']['v33']['healthy_fp']=7
    atomic_json(one,obj)
    fail=summarize_run(tmp_path,TEST,cfg,sha,group='prospective',boots=1000)
    assert not fail['acceptance']['passed']  # one clustered seed can fail Wilson bound / cluster bound


def test_refuse_mismatched_hash_or_config(tmp_path):
    cfg=FusionConfigV33()
    atomic_json(tmp_path/'s912.json',_case(912,'prospective','old',cfg))
    with pytest.raises(ValueError):summarize_run(tmp_path,TEST,cfg,'new',group='prospective')
    with pytest.raises(ValueError):summarize_run(tmp_path,TEST,FusionConfigV33(v11_hits=6),'old',group='prospective')


def test_development_requires_fresh_evidence(tmp_path):
    with pytest.raises(FileNotFoundError):score_configs(tmp_path)
    assert len(candidate_configs())==8
