"""Freeze HISTORICALLY DEVELOPED v35 model for a NEW prospective trial.

Source: original already-opened v35 traces 1264..1407. No outcomes from future
Sionna seeds are used. The threshold is historical OOF-selected; no claim of
independent calibration. Outputs research recommendations, not hardware actions.
"""
from __future__ import annotations
from pathlib import Path
import json,hashlib
import numpy as np,joblib
from sklearn.base import clone
from train_v35_gate import models,measures
from qualification import wilson
ROOT=Path(__file__).resolve().parent
MODEL=ROOT/'frozen_candidate'
MODEL.mkdir(exist_ok=True)
WITHIN_HISTORICAL_THRESHOLD=0.18
with np.load(ROOT/'historical_features.npz') as z:data={k:z[k] for k in z.files}
col=[str(c) for c in data['columns']]
inc=[i for i,c in enumerate(col) if not(c.startswith('v35_group') or c.endswith('_modal_id') or c=='v35_fired')]
feature_names=[col[i] for i in inc]
X=data['X'][:,inc];y=data['y'];candidate=data['X'][:,col.index('v35_fired')]>0
scores={}
for name in ['logistic_L2','rf_shallow']:
 m=clone(models()[name]);m.fit(X[candidate],y[candidate]);scores[name]=m
 print(name,'fitted',sum(candidate),'candidate cases; positives',sum(y[candidate]),flush=True)
bundle=dict(version='SANAD_v35_Learned_Gate_RESEARCH_RC0',
 trained_models=scores,weight={'logistic_L2':0.5,'rf_shallow':0.5},
 selected_threshold=WITHIN_HISTORICAL_THRESHOLD,
 frozen_v35_config='legacy_union',frozen_v33_config='frozen_v33',
 names=feature_names,all_feature_names=col,active_feature_name='v35_fired',
 training_seed_min=1264,training_seed_max=1407,
 training_provenance='ENTIRE HISTORICALLY VIEWED V35 PROSPECTIVE ARCHIVE; NEW OUT-OF-SAMPLE VALIDATION REQUIRED',
 action='NO_HARDWARE_ACTUATION')
joblib.dump(bundle,MODEL/'selected_model.joblib',compress=3)
with np.load(ROOT/'model'/'all_oof_probabilities.npz') as v:
 p=.5*v['logistic_L2']+.5*v['rf_shallow'];active=v['active'];y=v['y'];stream=v['stream'];seed=v['seed'];
 oof=measures(p,WITHIN_HISTORICAL_THRESHOLD,active,y,stream)
 pred=active&(p>=WITHIN_HISTORICAL_THRESHOLD)
 baseline33=data['X'][:,col.index('v33_fired')]>0
 baseline35=active
 seeds=np.array(sorted(set(seed)));n=len(seeds)
 per_seed=lambda b,positive:np.array([np.sum(b[(seed==s)&positive]) for s in seeds],int)
 positives=y==1; healthy=(y==0)&(stream=='healthy')
 tp=per_seed(pred,positives);fp=per_seed(pred,healthy)
 tp33=per_seed(baseline33,positives);tp35=per_seed(baseline35,positives)
 fp33=per_seed(baseline33,healthy);fp35=per_seed(baseline35,healthy)
 rng=np.random.default_rng(351233);draws=rng.integers(0,n,size=(10000,n))
 ci=lambda a,den:np.quantile(a[draws].sum(axis=1)/den,[.025,.975]).tolist()
 stats=dict(oof=oof,
  cluster_far_ci95=ci(fp,7*n),cluster_recall_ci95=ci(tp,2*n),
  paired_recall_gain_vs_v33_ci95=ci(tp-tp33,2*n),
  paired_far_diff_vs_v33_ci95=ci(fp-fp33,7*n),
  paired_recall_gain_vs_v35_ci95=ci(tp-tp35,2*n),
  paired_far_diff_vs_v35_ci95=ci(fp-fp35,7*n),
  dataset_hash=hashlib.sha256((ROOT/'historical_features.npz').read_bytes()).hexdigest(),
  model_hash=hashlib.sha256((MODEL/'selected_model.joblib').read_bytes()).hexdigest(),
  baseline_v33=dict(tp=int(tp33.sum()),fp=int(fp33.sum())),
  baseline_v35=dict(tp=int(tp35.sum()),fp=int(fp35.sum())),
  protocol='TRAINED_ON_PREVIOUSLY_VIEWED_SEEDS_1264_1407__NOT_INDEPENDENT',
  historical_threshold_selection=True,source='v35 frozen legacy_union proxies',
  new_independent_seeds_required=True,acceptance_verified=False)
 print('HISTORICAL OOF',json.dumps(stats['oof']),flush=True)
 print('FAR CLUSTER CI',stats['cluster_far_ci95'],'RECALL CLUSTER CI',stats['cluster_recall_ci95'],flush=True)
 print('v33 DELTA',stats['paired_recall_gain_vs_v33_ci95'],flush=True)
 (MODEL/'model_card.json').write_text(json.dumps(stats,indent=2))
 (MODEL/'feature_names.json').write_text(json.dumps(feature_names,indent=2))

if __name__=='__main__':pass
