"""SANAD v34 preregistered fresh-seed experiment; NOT a field qualification.

Do not use v33's disclosed evaluation seeds (912..1055) for v34 model
selection or v34 prospective testing. v34 development = 1056..1087;
prospective = 1088..1231. Each independent Sionna channel seed has seven
correlated antenna arrays, two injected fault arrays and seven healthy stream
controls. Bootstrap *channel seeds*, not array observations.
"""
from __future__ import annotations
from dataclasses import asdict,replace
from pathlib import Path
import hashlib,json,os,tempfile
import numpy as np
from qualification import wilson,validate_covariance
from v32_replay import extract_seed
from v33_study import trace_metrics as trace_metrics_v33
from sanad_v33 import FusionConfigV33
from sanad_v34 import FusionConfigV34
from v34_replay import replay_trace
from qa_integrity import validate_trace, atomic_record, read_record

DEV=tuple(range(1056,1088))
TEST=tuple(range(1088,1232))
PROTOCOL='V34_MODULAR_RF_FUSION_DEV_1056_1087_TEST_1088_1231_RC0'
SOURCE_FILES=(
    'sanad_v34.py','v34_replay.py','v34_study.py','config_v34.json',
    'sanad_v33.py','v33_replay.py','v33_study.py','sanad_v32.py',
    'v32_replay.py','v32_prospective.py','sanad_v30.py','sanad_v29.py',
    'v29_research.py','detect_v11.py','monitor_v8.py','glr_compare.py',
    'qualification.py','sionna_gen.py','sionna_cuda_v34.py','config_v33_reference.json','config_frozen.json',
    'qa_integrity.py','qa_case_audit.py','PROTOCOL_v34.md','QA_PROCESS_REVIEW.md','QA_README.md','requirements-cpu.txt','test_v34.py','test_v34_study.py','test_v34_qa.py',
)


def sha_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
    return h.hexdigest()


def source_hash(root):
    h=hashlib.sha256();root=Path(root)
    for name in SOURCE_FILES:
        h.update(name.encode()+b'\0'+bytes.fromhex(sha_file(root/name)))
    return h.hexdigest()


def atomic_json(path,ob):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',encoding='utf8',dir=path.parent,prefix=path.stem,suffix='.tmp',delete=False) as f:
        json.dump(ob,f,sort_keys=True,indent=2);temp=f.name
    os.replace(temp,path)


def candidate_configs():
    """Design grid fixed before unseen 1056..1231 seeds. No v33 test tuning."""
    b=FusionConfigV34()
    specs=[
        {},
        {'quality_score_multiple':1.20,'quality_dominance':2.0},
        {'quality_score_multiple':1.60,'quality_dominance':2.2},
        {'quality_hits':4},
        {'quality_hits':8},
        {'partial_v11_hits':1},
        {'fast_rescue':True},
        {'cohort_review_at':3},
    ]
    return tuple(replace(b,**x) for x in specs)


def count_outcomes(trace, cfg:FusionConfigV34):
    """Primary confirmed alerts only, never count REVIEW-only as a true positive."""
    results={}
    for stream in ('healthy','injected'):
        out=replay_trace(trace,stream,cfg)
        end=out['final'][260:]
        expected=trace[f'{stream}_expected'];onsets=trace[f'{stream}_onset']
        results[stream]=dict(fp=0,tp=0,post=0,neighbor_fp=0,delay=[],correct=0,
                             named_when_alerted=0,review=0,review_only=0,cohort_review=0)
        r=results[stream]
        for a in range(7):
            fired=bool(end[:,a].any())
            r['review']+=int(out['review'][260:,a].any())
            r['review_only']+=int(out['review_only'][260:,a].any())
            r['cohort_review']+=int(out['cohort'][260:,a].any())
            if stream=='healthy':r['fp']+=int(fired)
            elif expected[a]>0:
                r['tp']+=int(fired)
                onset=int(onsets[a]);found=np.flatnonzero(out['final'][onset:,a])
                r['post']+=int(bool(len(found)))
                if len(found):r['delay'].append(int(found[0]))
                cor=int(int(out['antenna'][-1,a])==int(expected[a]))
                r['correct']+=cor
                r['named_when_alerted']+=cor*int(fired)
            else:r['neighbor_fp']+=int(fired)
    h=results['healthy'];f=results['injected']
    return dict(healthy_fp=h['fp'],fault_tp=f['tp'],post_onset_tp=f['post'],
                neighbor_fp=f['neighbor_fp'],delay_reports=f['delay'],
                terminal_named_correct=f['correct'],named_when_alerted=f['named_when_alerted'],
                review_healthy=h['review'],review_fault=f['review'],
                review_only_healthy=h['review_only'],review_only_fault=f['review_only'],
                cohort_review_healthy=h['cohort_review'],cohort_review_fault=f['cohort_review'])


def trace_metrics(trace, cfg:FusionConfigV34):
    # The frozen prior-version algorithms are descriptive baselines, NOT
    # additional sources used to make v34 decisions or tune by TEST outcome.
    old=trace_metrics_v33(trace,FusionConfigV33())
    new=count_outcomes(trace,cfg)
    result={m:old['methods'][m] for m in ('v11','v30','v32','v33')}
    result['v34']={k:new[k] for k in (
        'healthy_fp','fault_tp','post_onset_tp','neighbor_fp','delay_reports',
        'terminal_named_correct','named_when_alerted')}
    return {'methods':result,'review':{k:new[k] for k in new if 'review' in k}}


def score_configs(cache_dir):
    """Strict development-only selection on ALL 32 new, untouched seeds."""
    traces=[]
    for sd in DEV:
        p=Path(cache_dir)/f's{sd}.npz'
        if not p.is_file():raise FileNotFoundError(f'Missing new development data: {p}')
        meta=p.with_suffix('.manifest.json')
        if not meta.is_file():raise ValueError(f'No provenance manifest for {p}')
        m=json.loads(meta.read_text())
        if (m.get('seed')!=sd or m.get('protocol')!=PROTOCOL or
            m.get('source_sha256')!=source_hash(Path(__file__).parent) or
            m.get('evidence_sha256')!=sha_file(p)):
            raise ValueError(f'Development evidence provenance invalid: {p}')
        with np.load(p,allow_pickle=False) as z:trace=dict(z)
        validate_trace(trace,'healthy');validate_trace(trace,'injected')
        traces.append(trace)
    rows=[]
    for cfg in candidate_configs():
        metrics=[count_outcomes(t,cfg) for t in traces]
        tp=sum(x['fault_tp'] for x in metrics);fp=sum(x['healthy_fp'] for x in metrics)
        n=len(DEV);rec=tp/(2*n);fpr=fp/(7*n)
        point_feasible=rec>=.90 and fpr<.02
        # Fixed development objective; not a prospective qualification claim.
        loss=5*max(0,fpr-.02)+3*max(0,.90-rec)+0.4*fpr-0.1*rec
        rows.append(dict(config=asdict(cfg),fault_tp=tp,healthy_fp=fp,
                         recall=rec,fpr=fpr,feasible_point=point_feasible,loss=loss))
    good=[r for r in rows if r['feasible_point']]
    selected=(sorted(good,key=lambda r:(r['fpr'],-r['recall']))[0] if good
              else sorted(rows,key=lambda r:(r['loss'],r['fpr'],-r['recall']))[0])
    return dict(status='COMPLETE',protocol=PROTOCOL,research_only=True,
                development_seeds=list(DEV),prospective_reserved=list(TEST),
                candidates=len(rows),point_feasible_candidates=len(good),
                selected=selected,grid=rows,
                note='If no development candidate meets targets, best-effort candidate remains NONQUALIFIED. Prospective must remain independently frozen.')



def prepare_evidence(seed,cov_dir,cache_dir,src_dir,expected_source_sha):
    """Bind each cached proxy trace to an immutable source and covariance SHA.

    A partially written cache without an integrity manifest is refused rather
    than silently reused. A rerun may replay an existing validated cache.
    """
    if seed not in DEV+TEST:raise ValueError('Non-v34 seed prohibited')
    if source_hash(src_dir)!=expected_source_sha:
        raise ValueError('Source changed; refuse evidence reuse')
    p=Path(cov_dir)/f's{seed}.npz'
    cp=Path(cache_dir)/f's{seed}.npz'
    mp=Path(cache_dir)/f's{seed}.manifest.json'
    if not p.is_file():raise FileNotFoundError(f'New channel covariance missing: {p}')
    with np.load(p,allow_pickle=False) as z:validate_covariance(z[f's{seed}'])
    covhash=sha_file(p)
    if cp.exists() != mp.exists():
        raise ValueError('Unpaired evidence cache and manifest; audit before continuing')
    if not cp.exists():
        cp.parent.mkdir(parents=True,exist_ok=True)
        extract_seed(p,src_dir,seed,cp)
        atomic_json(mp,dict(seed=seed,protocol=PROTOCOL,
                            source_sha256=expected_source_sha,
                            covariance_sha256=covhash,
                            evidence_sha256=sha_file(cp)))
    md=json.loads(mp.read_text())
    if (md.get('seed')!=seed or md.get('protocol')!=PROTOCOL or
        md.get('source_sha256')!=expected_source_sha or
        md.get('covariance_sha256')!=covhash or
        md.get('evidence_sha256')!=sha_file(cp)):
        raise ValueError('Evidence/cache provenance mismatch')
    with np.load(cp,allow_pickle=False) as z:
        for stream in ('healthy','injected'):
            validate_trace(z,stream)
    return cp,md


def evaluate_seed(seed,group,cov_dir,cache_dir,run_dir,src_dir,expected_hash,cfg):
    if group not in ('development','prospective'):raise ValueError('Invalid group')
    expected=DEV if group=='development' else TEST
    if seed not in expected:raise ValueError('Forbidden seed for chosen group')
    if source_hash(src_dir)!=expected_hash:raise ValueError('Source changed since freeze')
    run_dir=Path(run_dir);run_dir.mkdir(parents=True,exist_ok=True)
    path=run_dir/f's{seed}.json'
    if path.exists():
        old=read_record(path)
        if (old.get('seed')!=seed or old.get('source_sha256')!=expected_hash
            or old.get('group')!=group or old.get('protocol')!=PROTOCOL
            or old.get('config')!=asdict(cfg)):
            raise ValueError('Existing checkpoint differs; refusing to mix results')
        _,provenance=prepare_evidence(seed,cov_dir,cache_dir,src_dir,expected_hash)
        if (old.get('covariance_sha256')!=provenance['covariance_sha256'] or
            old.get('evidence_sha256')!=provenance['evidence_sha256']):
            raise ValueError('Saved result references altered data')
        return old
    cp,provenance=prepare_evidence(seed,cov_dir,cache_dir,src_dir,expected_hash)
    with np.load(cp,allow_pickle=False) as z:trace=dict(z)
    out=dict(seed=seed,group=group,protocol=PROTOCOL,
             source_sha256=expected_hash,config=asdict(cfg),
             covariance_sha256=provenance['covariance_sha256'],
             evidence_sha256=provenance['evidence_sha256'],
             research_only=True,**trace_metrics(trace,cfg))
    return atomic_record(path,out)


def summarize(run_dir,seeds,cfg,expected_hash,*,group,boots=2500):
    expected=DEV if group=='development' else TEST
    if tuple(seeds)!=expected:raise ValueError('Incorrect seed partition')
    rows={}
    for sd in seeds:
        p=Path(run_dir)/f's{sd}.json'
        if not p.exists():continue
        r=read_record(p)
        if (r.get('seed')!=sd or r.get('source_sha256')!=expected_hash
            or r.get('protocol')!=PROTOCOL or r.get('group')!=group or
            r.get('config')!=asdict(cfg)):
            raise ValueError(f'Checkpoint manifest mismatch: {p}')
        rows[sd]=r
    n=len(rows)
    out={'status':'COMPLETE' if n==len(seeds) else 'INCOMPLETE',
         'group':group,'completed':n,'required':len(seeds),
         'protocol':PROTOCOL,'source_sha256':expected_hash,
         'config':asdict(cfg),'methods':{},'acceptance':None,'research_only':True}
    if not n:return out
    ids=list(rows)
    for method in ('v11','v30','v32','v33','v34'):
        total=lambda key:sum(r['methods'][method][key] for r in rows.values())
        fp=int(total('healthy_fp'));tp=int(total('fault_tp'))
        delays=[x for r in rows.values() for x in r['methods'][method]['delay_reports']]
        out['methods'][method]=dict(fault_tp=tp,fault_n=2*n,recall=tp/(2*n),
               healthy_fp=fp,healthy_n=7*n,fpr=fp/(7*n),
               wilson_false_ci=wilson(fp,7*n),
               median_detection_delay_h=float(np.median(delays))/4 if delays else None,
               correct_named_terminal=int(total('terminal_named_correct')),
               correct_named_when_alerted=int(total('named_when_alerted')),
               neighbor_fp=int(total('neighbor_fp')))
    if boots and n>=2:
        rng=np.random.default_rng(340512)
        draws=rng.integers(0,n,size=(boots,n))
        for m in ('v11','v30','v32','v33','v34'):
            f=np.array([rows[s]['methods'][m]['healthy_fp'] for s in ids])
            t=np.array([rows[s]['methods'][m]['fault_tp'] for s in ids])
            out['methods'][m]['cluster_false_ci']=np.quantile(f[draws].sum(axis=1)/(7*n),[.025,.975]).tolist()
            out['methods'][m]['cluster_recall_ci']=np.quantile(t[draws].sum(axis=1)/(2*n),[.025,.975]).tolist()
        for base in ('v11','v30','v32','v33'):
            d=np.array([rows[s]['methods']['v34']['fault_tp']-rows[s]['methods'][base]['fault_tp'] for s in ids])
            out[f'paired_gain_v34_vs_{base}_ci95']=np.quantile(d[draws].sum(axis=1)/(2*n),[.025,.975]).tolist()
    out['review']={k:int(sum(r['review'][k] for r in rows.values()))
                   for k in ('review_healthy','review_fault','review_only_healthy',
                             'review_only_fault','cohort_review_healthy','cohort_review_fault')}
    if out['status']=='COMPLETE' and group=='prospective':
        v=out['methods']['v34']
        # All gates must pass; zero bootstrap replicates is insufficient.
        w=v['wilson_false_ci'][1]
        c=v.get('cluster_false_ci',[None,None])[1]
        g=out.get('paired_gain_v34_vs_v11_ci95',[None,None])[0]
        passed=(c is not None and g is not None and v['recall']>=.9
                and w<.02 and c<.02 and g>0)
        out['acceptance']=dict(passed=bool(passed),recall_point=v['recall'],
                               wilson_false_upper=w,cluster_false_upper=c,
                               paired_recall_gain_lower_v11=g,
                               rule='Recall >=90%, BOTH 95% upper false-alarm bounds <2%, lower paired seed-bootstrap recall gain over v11 >0; 144 new seeds and hash intact')
    return out
