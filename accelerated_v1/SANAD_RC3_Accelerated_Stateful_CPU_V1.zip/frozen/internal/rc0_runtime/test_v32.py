import unittest
import numpy as np
from sanad_v32 import FusionConfig
from v32_replay import gate_evidence, configs
class T(unittest.TestCase):
 def test_gate_requirements(self):
  t=30;f=np.full((2,t,7,3),np.nan,np.float32)
  b=np.zeros((t,7),np.uint8)
  cfg=FusionConfig(dominance_ratio=1.8,persistence=10,recent=15,v11_confirm_min=5,v11_confirm_window=8,v11_identity_min=0)
  for x in range(10,25):f[1,x,3]=[0.95,2.0,4]
  a,con,sp=gate_evidence(b,f,cfg)
  self.assertTrue(sp[24,3]);self.assertFalse(a[23,2]);self.assertFalse(con[24,3]);self.assertTrue(a[24,3])
  b[15:20,2]=1
  a,con,sp=gate_evidence(b,f,cfg)
  self.assertTrue(con[19,2]);self.assertTrue(a[19,2])
  self.assertFalse(a[24,2])
 def test_false_v11_single(self):
  b=np.zeros((30,7),np.uint8);b[27,2]=1
  f=np.full((2,30,7,3),np.nan,np.float32)
  a,_,_=gate_evidence(b,f,FusionConfig(v11_identity_min=0))
  self.assertFalse(a.any())
 def test_antenna_identity_is_required(self):
  cfg=FusionConfig(v11_identity_min=3)
  b=np.zeros((30,7),np.uint8); b[20:25,4]=1
  f=np.full((2,30,7,3),np.nan,np.float32)
  names=np.zeros((30,7),np.int8)
  names[20:25,4]=[1,2,3,4,5]
  a,_,_=gate_evidence(b,f,cfg,raw_named=names)
  self.assertFalse(a[24,4])
  names[20:25,4]=[2,2,3,2,5]
  a,_,_=gate_evidence(b,f,cfg,raw_named=names)
  self.assertTrue(a[24,4])
 def test_guards(self):
  with self.assertRaises(ValueError):FusionConfig(persistence=20,recent=15)
  self.assertEqual(len(list(configs())),36)
if __name__=='__main__':unittest.main()
