from pathlib import Path
import hashlib,zipfile,json
ROOT=Path(__file__).parent
OUT=Path('/mnt/data/SANAD_v35_Learned_Gate_RC0_Training_and_GPU_Source.zip')
files=[]
for p in ROOT.rglob('*'):
 if not p.is_file() or any(z in p.parts for z in ('__pycache__','.pytest_cache','model')):continue
 if p.name.endswith('.pyc') or p.name.startswith('.') or p.name=='MANIFEST_RC0.json':continue
 files.append(p)
for p in (ROOT/'frozen_candidate').iterdir():
 if p.is_file():files.append(p)
for p in (ROOT/'model').iterdir():
 if p.is_file() and p.suffix!='joblib':files.append(p)
paths=sorted((str(p.relative_to(ROOT)),p) for p in set(files))
hashes={s:hashlib.sha256(p.read_bytes()).hexdigest() for s,p in paths}
manifest=dict(release='SANAD_v35_Learned_Gate_RC0',scope='historical training + frozen independent GPU prospective runner',
 research_only=True,local_qa='35 tests, 6 subtests',historical_seed_range='1264-1407 ALREADY VIEWED',
 fresh_prospective_seed_range='2500-2643 UNOPENED',model_sha256=hashes['frozen_candidate/selected_model.joblib'],
 files_sha256=hashes)
(ROOT/'MANIFEST_RC0.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for s,p in paths:z.write(p,arcname=s)
 z.write(ROOT/'MANIFEST_RC0.json',arcname='MANIFEST_RC0.json')
print('zip',OUT,OUT.stat().st_size,'files',len(paths)+1,'sha256',hashlib.sha256(OUT.read_bytes()).hexdigest())
