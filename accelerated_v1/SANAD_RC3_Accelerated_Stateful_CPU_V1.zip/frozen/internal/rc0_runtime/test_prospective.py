import unittest, tempfile, json
from pathlib import Path
from sanad_v32 import FusionConfig
from v32_prospective import summarize,FRESH,PROTOCOL,write_json_atomic,frozen_source_hash
class ProspectiveTests(unittest.TestCase):
 def test_complete_and_cluster_gate(self):
  h='fictional-unit-test-hash'
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)
   for sd in FRESH:
    rows={}
    for m in ('v11','v30','v32'):
     rows[m]=dict(healthy_fp=0,fault_tp=1 if m=='v11' else 2,
             post_onset_tp=2,neighbor_fp=0,delay_reports=[12,21],named_correct=2,named_when_alerted=2)
    write_json_atomic(p/f's{sd}.json',dict(protocol=PROTOCOL,source_sha256=h,seed=sd,rows=rows))
   s=summarize(p,FusionConfig(),h,boots=200)
   self.assertEqual(s['status'],'COMPLETE')
   self.assertEqual(s['methods']['v32']['fault_cases'],288)
   self.assertTrue(s['qualification']['gate_pass'])
   bad=p/'s744.json'
   obj=json.loads(bad.read_text());obj['rows']['v32']['healthy_fp']=7
   write_json_atomic(bad,obj)
   s2=summarize(p,FusionConfig(),h,boots=200)
   # 7/1008 healthy false alerts is <2% point estimate but Wilson upper >2%; fails
   self.assertFalse(s2['qualification']['gate_pass'])
 def test_freeze_guard(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);write_json_atomic(p/'s744.json',dict(protocol=PROTOCOL,source_sha256='wrong',seed=744,rows={}))
   with self.assertRaises(ValueError):summarize(p,FusionConfig(),'correct',boots=0)
if __name__=='__main__':unittest.main()
