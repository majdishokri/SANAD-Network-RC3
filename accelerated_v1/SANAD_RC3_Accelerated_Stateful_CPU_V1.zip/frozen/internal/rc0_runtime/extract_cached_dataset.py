from __future__ import annotations
from pathlib import Path
import argparse,time
import numpy as np
from feature_engineering import extract_dataset

def main():
 p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=1264);p.add_argument('--stop',type=int,default=1408);p.add_argument('--cache',default='/mnt/data');p.add_argument('--out',default='/mnt/data/SANAD_V35_Learned_Gate_Research/historical_features.npz');a=p.parse_args()
 files=[Path(a.cache)/f's{s}.npz' for s in range(a.start,a.stop)]
 missing=[str(f) for f in files if not f.exists()]
 if missing:raise RuntimeError(f'Missing {len(missing)} traces; no synthetic substitution: {missing[:5]}')
 parts=[];st=time.monotonic()
 for i in range(0,len(files),12):
  parts.append(extract_dataset(files[i:i+12]));print('Extracted',min(i+12,len(files)),'/144 seeds, elapsed',round(time.monotonic()-st,1),'sec',flush=True)
 columns=parts[0]['columns']
 if any(p['columns']!=columns for p in parts):raise RuntimeError('Feature schema drift')
 joined={k:np.concatenate([p[k] for p in parts],axis=0) for k in ('X','y','seed','stream','array','case_sha')}
 if not (len(joined['X'])==(a.stop-a.start)*14 and joined['y'].sum()==(a.stop-a.start)*2):raise RuntimeError('Bad cohort size')
 out=Path(a.out);out.parent.mkdir(exist_ok=True,parents=True)
 np.savez_compressed(out,**joined,columns=np.array(columns,dtype='<U100'))
 print('Wrote',out,'samples',len(joined['X']),'positives',joined['y'].sum(),'healthy',(a.stop-a.start)*7,flush=True)

if __name__=='__main__':main()
