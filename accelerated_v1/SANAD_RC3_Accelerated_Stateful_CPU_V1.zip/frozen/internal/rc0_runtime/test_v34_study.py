import json
from dataclasses import asdict
from pathlib import Path
import pytest
from sanad_v34 import FusionConfigV34
from qa_integrity import atomic_record
from v34_study import (DEV,TEST,PROTOCOL,source_hash,atomic_json,
                       candidate_configs,score_configs,evaluate_seed,summarize)

def row(seed,group,sha,cfg,fp=0,tp=2,oldtp=1):
    methods={}
    for m in ('v11','v30','v32','v33','v34'):
        hit=oldtp if m=='v11' else tp
        methods[m]=dict(healthy_fp=fp if m=='v34' else 0,fault_tp=hit,
                        post_onset_tp=hit,neighbor_fp=0,delay_reports=[12]*hit,
                        terminal_named_correct=hit,named_when_alerted=hit)
    review={k:0 for k in ('review_healthy','review_fault','review_only_healthy',
                          'review_only_fault','cohort_review_healthy','cohort_review_fault')}
    return dict(seed=seed,group=group,source_sha256=sha,protocol=PROTOCOL,
                config=asdict(cfg),methods=methods,review=review)


def test_no_reused_seed_partitions():
    assert DEV==tuple(range(1056,1088)) and TEST==tuple(range(1088,1232))
    assert not(set(DEV)&set(TEST)) and min(DEV)>1055
    assert len(candidate_configs())==8
    assert all(isinstance(x,FusionConfigV34) for x in candidate_configs())
    with pytest.raises(ValueError):evaluate_seed(1055,'development','x','y','z','u','h',FusionConfigV34())
    with pytest.raises(ValueError):evaluate_seed(1088,'development','x','y','z','u','h',FusionConfigV34())
    with pytest.raises(ValueError):evaluate_seed(1056,'prospective','x','y','z','u','h',FusionConfigV34())


def test_no_partial_qualification(tmp_path):
    cfg=FusionConfigV34();sha='abcd'
    atomic_record(tmp_path/'s1088.json',row(1088,'prospective',sha,cfg))
    r=summarize(tmp_path,TEST,cfg,sha,group='prospective',boots=100)
    assert r['status']=='INCOMPLETE' and r['acceptance'] is None


def test_complete_acceptance_and_counterfactual_fail(tmp_path):
    cfg=FusionConfigV34();sha='abcd'
    for sd in TEST:atomic_record(tmp_path/f's{sd}.json',row(sd,'prospective',sha,cfg))
    r=summarize(tmp_path,TEST,cfg,sha,group='prospective',boots=150)
    assert r['status']=='COMPLETE' and r['acceptance']['passed']
    x=tmp_path/'s1088.json';ob=json.loads(x.read_text())
    ob['methods']['v34']['healthy_fp']=7;atomic_json(x,ob)
    with pytest.raises(ValueError, match='SHA-256 mismatch'):
        summarize(tmp_path,TEST,cfg,sha,group='prospective',boots=150)


def test_refuse_mixed_config_hash_and_group(tmp_path):
    cfg=FusionConfigV34();sha='abcd'
    atomic_record(tmp_path/'s1088.json',row(1088,'prospective',sha,cfg))
    with pytest.raises(ValueError):summarize(tmp_path,TEST,cfg,'wrong',group='prospective')
    with pytest.raises(ValueError):summarize(tmp_path,TEST,FusionConfigV34(quality_hits=7),sha,group='prospective')
    assert summarize(tmp_path,DEV,cfg,sha,group='development')['status']=='INCOMPLETE'
    atomic_record(tmp_path/'s1056.json',row(1056,'prospective',sha,cfg))
    with pytest.raises(ValueError):summarize(tmp_path,DEV,cfg,sha,group='development')


def test_no_development_evidence_error(tmp_path):
    with pytest.raises(FileNotFoundError):score_configs(tmp_path)


def test_source_hash_changes_with_edit(tmp_path):
    from v34_study import SOURCE_FILES
    src=Path(__file__).parent
    h=source_hash(src)
    assert len(h)==64
    # Copy exact inputs, then modify a single byte and assert SHA changes.
    for f in SOURCE_FILES:(tmp_path/f).write_bytes((src/f).read_bytes())
    assert source_hash(tmp_path)==h
    (tmp_path/'sanad_v34.py').write_bytes((tmp_path/'sanad_v34.py').read_bytes()+b'\n# mutation')
    assert source_hash(tmp_path)!=h
