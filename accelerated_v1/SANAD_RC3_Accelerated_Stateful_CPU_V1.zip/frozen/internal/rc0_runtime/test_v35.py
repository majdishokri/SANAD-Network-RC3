import numpy as np
import pytest
from dataclasses import replace
from temporal_v35 import FrozenTemporalEvidenceV35,TemporalConfigV35,extract_delta,PROJECTOR
from sanad_v35 import EvidenceFusionV35,FusionConfigV35
from sanad_v33 import ElementEvidence


def test_baseline_frozen_no_future_learning():
    e=FrozenTemporalEvidenceV35()
    for t in range(120):
        assert e.step({0: np.full(16,.03)})[0] is None
    assert e.ref[0] is None  # first decision at report 120
    e.step({0:np.full(16,.03)})
    assert e.ref[0] is not None
    before=e.ref[0].copy()
    for _ in range(17):
        x=np.zeros(16);x[2]=3;x[10]=25
        r=e.step({0:x})
    assert np.array_equal(before,e.ref[0]);assert r[0].element==3
    assert r[0].score>0 and r[0].dominance>=1


def test_missing_and_common_mode_are_not_faults():
    e=FrozenTemporalEvidenceV35()
    for _ in range(120):e.step({0:np.zeros(16)})
    for _ in range(18):r=e.step({0:np.r_[np.ones(8)*1.2,np.ones(8)*8.0]})
    assert r[0] is not None and r[0].score<.001
    assert r[1] is None
    for _ in range(10):assert e.step({})[0] is None


def test_reject_invalid_and_future_independence():
    with pytest.raises(ValueError):FrozenTemporalEvidenceV35().step({0:np.zeros(15)})
    with pytest.raises(ValueError):FrozenTemporalEvidenceV35().step({8:np.zeros(16)})
    with pytest.raises(ValueError):FrozenTemporalEvidenceV35(TemporalConfigV35(min_baseline=70))
    x={a:[np.zeros(16) for _ in range(300)] for a in range(7)}
    x[3][250]=np.array([5]*16)
    aa=extract_delta(x)
    assert aa.shape==(300,7,3) and np.isnan(aa[:120]).all()
    assert np.allclose(aa[:250],extract_delta({a:[*xs[:250],*[np.zeros(16) for _ in range(50)]] for a,xs in x.items()})[:250],equal_nan=True)


def test_temporal_strong_solo_and_ambiguous_cohort():
    c=FusionConfigV35()
    f=EvidenceFusionV35(c)
    no=[None]*7
    x=ElementEvidence(10.0,3.0,4)
    res=None
    for _ in range(16):res=f.step([False]*7,[0]*7,no,no,[x]+[None]*6,[True]*7)
    assert res[0].final_alert and res[0].antenna_1based==4
    assert not res[0].review_only
    f=EvidenceFusionV35(c)
    for _ in range(17):res=f.step([False]*7,[0]*7,no,no,[x]*4+[None]*3,[True]*7)
    assert not any(v.final_alert for v in res[:4]);assert all(v.cohort_ambiguous for v in res[:4])


def test_unsupported_temporal_stays_review():
    f=EvidenceFusionV35()
    e=ElementEvidence(4.4,1.6,3)
    for _ in range(17):res=f.step([False]*7,[0]*7,[None]*7,[None]*7,[e]+[None]*6)
    assert res[0].review_only and not res[0].final_alert
    assert res[0].delta_persistent and not res[0].delta_supported


def test_spatial_supported_delta_promotes():
    f=EvidenceFusionV35()
    e=ElementEvidence(4.5,1.6,3)
    fast=ElementEvidence(1.0,1.8,3)
    for _ in range(16):res=f.step([False]*7,[0]*7,[fast]+[None]*6,[None]*7,[e]+[None]*6)
    assert res[0].final_alert and res[0].delta_supported


def test_invalid_config_and_nan_evidence():
    with pytest.raises(ValueError):FusionConfigV35(delta_hits=20)
    with pytest.raises(ValueError):FusionConfigV35(delta_solo_score=3)
    f=EvidenceFusionV35()
    with pytest.raises(ValueError):f.step([False]*7,[0]*7,[None]*7,[None]*7,[None]*6)
