"""CPU synthetic integration smoke, NOT RF performance evidence."""
from pathlib import Path
import tempfile
import numpy as np
from v35_replay import extract_seed_v35,validate_v35_trace,replay_trace_v35
from sanad_v35 import FusionConfigV35,SANADNetworkV35
from glr_compare import pipeline


def run():
    rng=np.random.default_rng(8852);t=300;n=7
    a=rng.normal(size=(n,8))+1j*rng.normal(size=(n,8))
    a/=np.linalg.norm(a,axis=1,keepdims=True)
    cov=np.empty((t,n,8,8),complex)
    for i in range(t):
        for j in range(n):
            v=a[j]+0.008*(rng.normal(size=8)+1j*rng.normal(size=8))
            cov[i,j]=np.eye(8)+3*np.outer(v,np.conj(v))
    with tempfile.TemporaryDirectory() as td:
        f=Path(td)/'s9999.npz';np.savez_compressed(f,s9999=cov)
        dest=Path(td)/'ev.npz';extract_seed_v35(f,Path(__file__).parent,9999,dest)
        with np.load(dest,allow_pickle=False) as z:
            trace=dict(z)
        for stream in ('healthy','injected'):
            validate_v35_trace(trace,stream)
            out=replay_trace_v35(trace,stream,FusionConfigV35())
            assert out['final'].shape==(300,7)
        from v35_study import trace_metrics
        metrics=trace_metrics(trace,FusionConfigV35())
        assert set(metrics['methods'])=={'v11','v30','v32','v33','v34','v35'}
        vectors,_=pipeline(cov,900000+9999,with_faults=False)
        net=SANADNetworkV35(cal_dir=Path(__file__).parent,config=FusionConfigV35())
        actual=[]
        for k in range(300):
            res=net.update({j:vectors[j][k] for j in range(7) if vectors[j][k] is not None})
            actual.append([r.final_alert for r in res])
        assert np.array_equal(np.asarray(actual),replay_trace_v35(trace,'healthy',FusionConfigV35())['final'])
        return {'online_replay':'EXACT','streams':2,'periods':300,'arrays':7,'status':'ENGINEERING_SMOKE_ONLY'}

if __name__=='__main__':print(run())
