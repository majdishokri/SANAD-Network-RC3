"""Exploratory seed-grouped out-of-fold diagnostic; all historical seeds previously viewed."""
from pathlib import Path
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import numpy as np,json
from train_v35_gate import measures
with np.load(Path(__file__).parent/'historical_features.npz') as z: d={k:z[k] for k in z.files}
col=[str(c) for c in d['columns']]
selected=[i for i,c in enumerate(col) if not (c.startswith('v35_group') or c.endswith('_modal_id') or c=='v35_fired')]
X=d['X'][:,selected];y=d['y'];seed=d['seed'];stream=d['stream']
candidate=d['X'][:,col.index('v35_fired')]>0
raw33=d['X'][:,col.index('v33_fired')]>0
folds=GroupKFold(n_splits=4)
scores=np.zeros(len(y));foldidx=np.zeros(len(y),int)
for i,(train,test) in enumerate(folds.split(X,y,groups=seed)):
 m=Pipeline([('z',StandardScaler()),('lr',LogisticRegression(max_iter=3000,C=.1,class_weight='balanced'))])
 train=train[candidate[train]]
 m.fit(X[train],y[train]);scores[test]=m.predict_proba(X[test])[:,1];foldidx[test]=i
assert len(set(seed))==144
rows=[]
for threshold in [0.05,.08,.10,.12,.15,.18,.20,.25,.30,.35,.40,.45,.50,.55,.60,.65,.70,.75,.80]:
 outcome=measures(scores,threshold,candidate,y,stream);outcome['model']='v35_logistic_OOF';rows.append(outcome)
print('OBSERVED OOF TRADEOFF:')
for r in rows:print(f"threshold {r['threshold']:.2f} TP {r['tp']}/288 recall {r['recall']:.4f} FP {r['fp']}/1008 FAR {r['far']:.4f} Wilson {r['wilson_far_upper_95']:.4f}")
base={'v35':measures(candidate.astype(float),.5,candidate,y,stream),'v33':measures(raw33.astype(float),.5,raw33,y,stream)}
result={'status':'EXPLORATORY_OUT_OF_FOLD_HISTORICAL_NOT_INDEPENDENT','base':base,'threshold_frontier':rows,
 'folds':4,'seeds':'1264..1407','disclosure':'All seeds belong to an already viewed v35 archive; no threshold may be claimed independently validated from this scan.'}
(Path(__file__).parent/'model'/'cv_result.json').write_text(json.dumps(result,indent=2))
