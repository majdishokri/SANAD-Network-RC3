"""Causal replay for v34, sharing the production fusion implementation.

Fault labels are never passed to the model. The validation study accesses
synthetic truth only for post-hoc scoring.
"""
from __future__ import annotations
import numpy as np
from sanad_v34 import EvidenceFusionV34,FusionConfigV34,ElementEvidence
from qa_integrity import validate_trace


def replay_trace(trace:dict,stream:str,config:FusionConfigV34):
    validate_trace(trace,stream,require_truth=False)
    raw=np.asarray(trace[f'{stream}_v11'])
    named=np.asarray(trace[f'{stream}_v11_named'])
    feats=np.asarray(trace[f'{stream}_feats'])
    if raw.shape!=(300,7) or named.shape!=(300,7) or feats.shape!=(2,300,7,3):
        raise ValueError('Wrong Sionna evidence trace shape')
    engine=EvidenceFusionV34(config)
    keys=('final','review','review_only','v11','fast','strict','quality','agreement','cohort')
    flags={k:np.zeros((300,7),dtype=bool) for k in keys}
    named_out=np.zeros((300,7),dtype=np.int8)
    for t in range(300):
        evidence=[]
        for w in (0,1):
            x=[]
            for a in range(7):
                score,dom,antenna=feats[w,t,a]
                x.append(ElementEvidence(float(score),float(dom),int(antenna))
                         if np.isfinite(score) and np.isfinite(dom) and np.isfinite(antenna) else None)
            evidence.append(x)
        valid=[bool(np.isfinite(feats[:,t,a,0]).any()) for a in range(7)]
        out=engine.step(raw[t].tolist(),named[t].tolist(),evidence[0],evidence[1],valid)
        for a,x in enumerate(out):
            for key,value in [('final',x.final_alert),('review',x.review_candidate),
                              ('review_only',x.review_only),('v11',x.v11_persistent),
                              ('fast',x.v30_fast),('strict',x.v32_strict),('quality',x.spatial_quality),
                              ('agreement',x.spatial_correlated_agreement),('cohort',x.cohort_ambiguous)]:
                flags[key][t,a]=value
            named_out[t,a]=x.antenna_1based or 0
    return {**flags,'antenna':named_out}
