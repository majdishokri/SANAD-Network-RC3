# SANAD Network — v35 Learned Gate RC0

This is the **trained** v35 research model intended to reduce its false alarm fraction without losing most of its high recall. It is NOT a modification or replacement of the frozen historical v33/v35 releases.

### Tested locally

- Frozen v33/v35 replay predictions reproduce their saved outputs.
- 35 unit/regression tests and 6 parametrized subtests passed locally.
- Historical seed-grouped OOF (all previously viewed): **270 / 288 = 93.75% recall; 9 / 1008 = 0.89% healthy FAR**. Wilson 95% upper FAR = 1.69%; seed bootstrap upper = 1.49%. This is development-only model selection, NOT independent validation.
- The model trained on 1264..1343 and calibrated 1344..1375 had retrospective evaluation recall 56/64 = 87.5%, with 0/224 false alarms on seeds 1376..1407. The later OOF model family/threshold exploration is explicitly a further retrospective experiment and should not be called confirmatory.

### Files

- `feature_engineering.py`: read-only, endpoint causal features from frozen v33/v35 stream.
- `inference_v35_gate.py`: trained model interface (`FrozenV35LearnedGate`), no labels needed for prediction.
- `frozen_candidate/selected_model.joblib`: frozen blend fit on all 144 historical seeds (load only from trusted source).
- `frozen_candidate/model_card.json`: historical out-of-fold evaluation; checksum and limitations.
- `historical_features.npz`: compact training data including synthetic labels (labels used in **training only**).
- `extract_parallel.py`, `train_v35_gate.py`, `crossvalidate_v35.py`, `compare_models_oof.py`, `freeze_research_candidate.py`: reproducibility and exploratory development scripts.
- `prospective_gpu_runner.py`: new GPU-only Sionna study with 144 new seeds and Google Drive checkpoints.
- Original frozen v33, v34, v35, v11, v29 and other source modules for end-to-end reproduction.

### Running inference on archived trace

```python
import numpy as np
from inference_v35_gate import FrozenV35LearnedGate
with np.load('/path/to/s2500.npz', allow_pickle=False) as z:
    trace = {name: z[name] for name in z.files}
model = FrozenV35LearnedGate()
print(model.predict_trace(trace, 'healthy'))
```

No RF hardware actuation. New independent testing has not yet been executed in this artifact.
