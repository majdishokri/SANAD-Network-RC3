import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from qualification import SEEDS,PROTOCOL,wilson,aggregate_run_files,atomic_json

def make_case(seed, faults=False, m='v30', hit=False):
    return dict(mode='injected_two_faults' if faults else 'healthy_only',
         faulty=faults,last40_alarm={k:hit for k in ('v11','v29','v30')},
         any_alarm_after_learning={k:hit for k in ('v11','v29','v30')},
         post_onset_detected={k:hit if faults else None for k in ('v11','v29','v30')},
         delay_reports={k:5 if hit and faults else None for k in ('v11','v29','v30')},
         v11_terminal_correct=bool(hit and faults),v30_terminal_correct=bool(hit and faults))

def test_seed_count():
    assert len(SEEDS)==144 and len(SEEDS)*7==1008

def test_wilson_zero():
    assert wilson(0,1008)[1]<.004
    assert wilson(3,1008)[1]<.01

def test_summary_incomplete(tmp_path):
    seed=SEEDS[0]
    h=[make_case(seed) for _ in range(7)]
    f=[make_case(seed,i<2,hit=(i<2)) for i in range(7)]
    atomic_json(tmp_path/f's{seed}.json',dict(protocol=PROTOCOL,seed=seed,healthy=h,injected=f))
    result=aggregate_run_files(tmp_path,bootstrap_repetitions=100)
    assert result['status']=='INCOMPLETE'
    assert result['dataset']==dict(healthy_only_array_cases=7,faulty_array_cases=2,
                                    unaffected_arrays_under_injection=5,independent_channel_seeds=1)
    assert result['methods']['v30']['fault_recall_last40']['k']==2
    assert result['methods']['v30']['primary_healthy_false_alarm']['k']==0

def test_frozen_hash_rejects_modified(tmp_path):
    seed=SEEDS[0]
    h=[make_case(seed) for _ in range(7)]
    f=[make_case(seed,i<2) for i in range(7)]
    atomic_json(tmp_path/f's{seed}.json',dict(protocol=PROTOCOL,seed=seed,frozen_source_sha256='old',healthy=h,injected=f))
    try: aggregate_run_files(tmp_path,expected_frozen_hash='different')
    except ValueError as e:assert 'changed' in str(e)
    else:raise AssertionError('Frozen hash accepted despite change')
