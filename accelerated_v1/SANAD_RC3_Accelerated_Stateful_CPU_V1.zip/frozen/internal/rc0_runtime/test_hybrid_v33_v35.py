import numpy as np
import pytest
from sanad_v33 import ElementEvidence, EvidenceFusionV33, FusionConfigV33
from sanad_v35 import EvidenceFusionV35, FusionConfigV35
from sanad_hybrid_v33_v35 import HybridFusionV33V35, HybridConfig, load_frozen_v35_config, SANADHybridNetwork


def empty():
    return [None]*7


def test_true_v35_frozen_legacy_union():
    c = load_frozen_v35_config()
    assert isinstance(c, FusionConfigV35)
    assert c.base_policy == 'legacy_union'
    assert c.delta_hits == 9 and c.delta_window == 14


def test_v35_candidate_retained_without_misleading_v33_claim():
    hybrid = HybridFusionV33V35()
    strong = ElementEvidence(10.0, 3.0, 4)
    for i in range(16):
        row = hybrid.step([False]*7,[0]*7,empty(),empty(),[strong]+empty()[1:])
    assert row[0].sensitive_alert
    assert not row[0].conservative_alert
    assert not row[0].hybrid_alert
    assert row[0].review_required


def test_v33_frozen_confirmation_retained():
    hybrid = HybridFusionV33V35()
    for i in range(12):
        row = hybrid.step([True]+[False]*6,[3]+[0]*6,empty(),empty(),empty())
    assert row[0].conservative_alert
    assert row[0].hybrid_alert
    assert not any(x.hybrid_alert for x in row[1:])


def test_temporal_corrob_extra_path():
    hybrid = HybridFusionV33V35()
    strict = ElementEvidence(1.2, 2.2, 4)
    delta = ElementEvidence(10.0, 3.0, 4)
    for t in range(17):
        raw = [t==15]+[False]*6
        name = [4 if t==15 else 0]+[0]*6
        row = hybrid.step(raw,name,empty(),[strict]+empty()[1:],[delta]+empty()[1:])
    assert row[0].sensitive_alert
    assert not row[0].conservative_alert
    assert row[0].temporal_promoted
    assert row[0].hybrid_alert


def test_temporal_wrong_named_antenna_rejected():
    hybrid = HybridFusionV33V35()
    strict = ElementEvidence(1.2, 2.2, 4)
    delta = ElementEvidence(10.0, 3.0, 4)
    for t in range(17):
        raw = [t==15]+[False]*6
        name = [5 if t==15 else 0]+[0]*6
        row = hybrid.step(raw,name,empty(),[strict]+empty()[1:],[delta]+empty()[1:])
    assert row[0].sensitive_alert
    assert not row[0].temporal_promoted
    assert not row[0].hybrid_alert


def test_simultaneous_cohort_blocks_extra():
    hybrid = HybridFusionV33V35()
    strict = ElementEvidence(1.2, 2.2, 4)
    delta = ElementEvidence(10.0, 3.0, 4)
    for t in range(17):
        raw = [t==15]*4+[False]*3
        name = [4 if t==15 else 0]*4+[0]*3
        row = hybrid.step(raw,name,[None]*7,[strict]*4+[None]*3,[delta]*4+[None]*3)
    assert not any(x.temporal_promoted for x in row)


def test_invalid_never_alert():
    hybrid = HybridFusionV33V35()
    for t in range(18):
        row=hybrid.step([True]*7,[3]*7,empty(),empty(),empty(),[False]*7)
    assert not any(x.hybrid_alert or x.sensitive_alert or x.conservative_alert for x in row)


def test_exact_reference_parity_on_identical_evidence():
    hybrid=HybridFusionV33V35()
    r33=EvidenceFusionV33(FusionConfigV33())
    r35=EvidenceFusionV35(load_frozen_v35_config())
    rng=np.random.default_rng(13)
    for t in range(75):
        raw=[bool(x) for x in rng.random(7)<.16]
        named=[int(rng.integers(1,9)) if raw[a] else 0 for a in range(7)]
        fast=[ElementEvidence(1.2,2.2,int(rng.integers(1,9))) if x else None for x in rng.random(7)<.65]
        strict=[ElementEvidence(1.2,2.2,int(rng.integers(1,9))) if x else None for x in rng.random(7)<.65]
        delta=[ElementEvidence(6.2,2.3,int(rng.integers(1,9))) if x else None for x in rng.random(7)<.65]
        h=hybrid.step(raw,named,fast,strict,delta)
        v33=r33.step(raw,named,fast,strict)
        v35=r35.step(raw,named,fast,strict,delta)
        assert [x.conservative_alert for x in h]==[x.final_alert for x in v33]
        assert [x.sensitive_alert for x in h]==[x.final_alert for x in v35]


def test_bad_shape_and_config():
    h=HybridFusionV33V35()
    with pytest.raises(ValueError):h.step([False]*6,[0]*7,empty(),empty(),empty())
    with pytest.raises(ValueError):HybridConfig(temporal_raw_hits=0)


def test_end_to_end_input_shape():
    m=SANADHybridNetwork()
    for t in range(6):
        out=m.update({0:np.zeros(16)})
        assert len(out)==7 and out[0].action=='NO_HARDWARE_ACTUATION'
    with pytest.raises(ValueError):m.update({0:np.zeros(15)})
