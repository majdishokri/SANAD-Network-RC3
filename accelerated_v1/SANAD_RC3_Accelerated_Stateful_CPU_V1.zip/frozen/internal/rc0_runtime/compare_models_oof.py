from pathlib import Path
import json
import numpy as np
from sklearn.model_selection import GroupKFold
from sklearn.base import clone
from train_v35_gate import models,measures
from qualification import wilson

with np.load(Path(__file__).parent/'historical_features.npz') as z:d={k:z[k] for k in z.files}
cols=[str(c) for c in d['columns']]
inc=[i for i,c in enumerate(cols) if not(c.startswith('v35_group') or c.endswith('_modal_id') or c=='v35_fired')]
X=d['X'][:,inc];y=d['y'];seeds=d['seed'];stream=d['stream'];active=d['X'][:,cols.index('v35_fired')]>0
rows=[];prob={}
for name,obj in models().items():
 score=np.zeros(len(y));splitids=np.zeros(len(y),int)
 for fold,(tr,te) in enumerate(GroupKFold(4).split(X,y,groups=seeds)):
  mdl=clone(obj)
  mdl.fit(X[tr][active[tr]],y[tr][active[tr]])
  score[te]=mdl.predict_proba(X[te])[:,1];splitids[te]=fold
 prob[name]=score
 results=[measures(score,th,active,y,stream) for th in np.linspace(.03,.70,68)]
 feasible=[r for r in results if r['recall']>=.90 and r['wilson_far_upper_95']<.02]
 winner=max(feasible,key=lambda r:(r['recall'],-r['fp'],r['threshold'])) if feasible else max(results,key=lambda r:(r['recall']-6*r['far']))
 rows.append({'model':name,'historical_oof_best_descriptive':winner,'candidate_score_series':'separate_npz','feasible_threshold_count':len(feasible)})
 print(name,'best',round(winner['threshold'],3),'TP',winner['tp'],'FP',winner['fp'],'wilson',round(winner['wilson_far_upper_95'],4),flush=True)
# Blend logistic and forest probabilities, a new explicitly exploratory experiment.
for name,score in {'blend_lr_rf':(.5*prob['logistic_L2']+.5*prob['rf_shallow']),
                   'blend_lr_extra':(.5*prob['logistic_L2']+.5*prob['extra_shallow'])}.items():
 prob[name]=score
 results=[measures(score,th,active,y,stream) for th in np.linspace(.03,.70,68)]
 feasible=[r for r in results if r['recall']>=.90 and r['wilson_far_upper_95']<.02]
 winner=max(feasible,key=lambda r:(r['recall'],-r['fp'],r['threshold'])) if feasible else max(results,key=lambda r:(r['recall']-6*r['far']))
 rows.append({'model':name,'historical_oof_best_descriptive':winner,'feasible_threshold_count':len(feasible)})
 print(name,'best',round(winner['threshold'],3),'TP',winner['tp'],'FP',winner['fp'],'wilson',round(winner['wilson_far_upper_95'],4),flush=True)
np.savez_compressed(Path(__file__).parent/'model'/'all_oof_probabilities.npz',**{k:np.asarray(v) for k,v in prob.items()},seed=seeds,y=y,stream=stream,active=active)
(Path(__file__).parent/'model'/'historical_model_comparison.json').write_text(json.dumps({'not_independent':True,'selected_by_historical_scores':True,'models':rows},indent=2))
