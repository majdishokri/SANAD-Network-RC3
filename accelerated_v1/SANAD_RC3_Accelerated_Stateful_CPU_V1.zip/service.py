"""Small synchronous research ingestion facade; no RF control/network calls.

Only 300 nonoverlapping reports are supported by the frozen classifier.  It
is not a continuous early-warning or field-qualified streaming detector.
"""
from __future__ import annotations
from dataclasses import dataclass
from threading import Lock
from time import perf_counter_ns
from fast_engine import FastRC3

@dataclass(frozen=True)
class IngestResult:
    state: str
    reports_seen: int
    ready: bool
    cpu_ms: float
    alerts: tuple[bool,...] | None
    scores: tuple[float,...] | None
    action: str='NO_HARDWARE_ACTUATION'

class MonitorService:
    """Check sequence ordering; each session is a fixed 300-report epoch."""
    def __init__(self,engine:FastRC3|None=None):
        self.engine=engine or FastRC3()
        self._mutex=Lock()
        self._session=self.engine.session('healthy')
        self._next_seq=0

    def ingest(self,sequence_no:int,raw_v11,raw_named,feats,delta)->IngestResult:
        with self._mutex:
            if not isinstance(sequence_no,int) or sequence_no!=self._next_seq:
                raise ValueError(f'Out-of-order report: expected {self._next_seq}, got {sequence_no}')
            start=perf_counter_ns()
            result=self._session.push(raw_v11,raw_named,feats,delta)
            ms=(perf_counter_ns()-start)/1e6
            self._next_seq+=1
            ready=result is not None
            return IngestResult(
                'TERMINAL_RC3' if ready else 'COLLECTING',self._next_seq,ready,ms,
                tuple(result['alerts']) if ready else None,
                tuple(result['probabilities']) if ready else None)

    def reset(self):
        """Begin a new *nonoverlapping* 300-report block; does not claim sliding parity."""
        with self._mutex:
            self._session=self.engine.session('healthy')
            self._next_seq=0
