"""Regression and input-contract tests for the engineering-only RC3 candidate."""
from __future__ import annotations
import argparse,json,hashlib,time
from pathlib import Path
import numpy as np
from fast_engine import FastRC3,from_evidence
from fast_stats import make_features
from fast_upstream import features_from_replay
from service import MonitorService

HERE=Path(__file__).resolve().parent
UPSTREAM_SHA='18cccfaa9b27a17934bc2c3a1c22f0b7ed164b2af99c0ad738b33a595357a81e'


def run(files,output=None):
    engine=FastRC3()
    original=engine.reference
    import feature_engineering as fe
    assert hashlib.sha256(Path(fe.__file__).read_bytes()).hexdigest()==UPSTREAM_SHA
    count=0; max_prob=0.; max_feature=0.; max_upstream=0.
    first_sample=None
    t0=time.perf_counter_ns()
    summary={'files':[],'status':'engineering_regression_pass','qualified_field':False,
             'model_unchanged':True,'terminal_only':True}
    for f in files:
        with np.load(f,allow_pickle=False) as z:
            trace={k:z[k] for k in z.files}
        row={'seed':Path(f).stem,'streams':{}}
        for stream in ('healthy','injected'):
            x=make_features(trace,stream)
            x_ref=__import__('rc3').make_features(trace,stream)
            dx=float(np.max(np.abs(x-x_ref)))
            assert np.allclose(x,x_ref,rtol=1e-6,atol=1e-6),(f,stream,'RC3 feature divergence',dx)
            max_feature=max(max_feature,dx)
            replay=fe._replay_without_truth(trace,stream)
            ups,columns=features_from_replay(trace,stream,replay)
            ups_ref,cols_ref=fe.features_per_array(trace,stream)
            err=float(np.max(np.abs(ups-ups_ref)))
            assert columns==cols_ref and np.allclose(ups,ups_ref,rtol=1e-12,atol=1e-12)
            max_upstream=max(max_upstream,err)
            t=time.perf_counter_ns();ref=original.predict_trace(trace,stream);ref_ms=(time.perf_counter_ns()-t)/1e6
            t=time.perf_counter_ns();fast=engine.predict_trace(trace,stream);fast_ms=(time.perf_counter_ns()-t)/1e6
            t=time.perf_counter_ns();incremental=from_evidence(engine,trace,stream);incr_ms=(time.perf_counter_ns()-t)/1e6
            assert ref['alerts']==fast['alerts']==incremental['alerts'],(f,stream)
            e=max(abs(a-b) for a,b in zip(ref['probabilities'],incremental['probabilities']))
            assert e<=1e-7,(f,stream,e)
            max_prob=max(max_prob,e);count+=1
            row['streams'][stream]={'alerts':ref['alerts'],'max_probability_abs_error':e,
                'reference_full_ms':ref_ms,'optimized_stateless_full_ms':fast_ms,
                'optimized_incremental_total_ms':incr_ms}
            if first_sample is None:first_sample=trace
        summary['files'].append(row)
    # Safety: no RC3 prediction before 300th report, sequence check rejects gaps.
    if first_sample is not None:
        ss=MonitorService(engine)
        for t in range(299):
            v=ss.ingest(t,first_sample['healthy_v11'][t],first_sample['healthy_v11_named'][t],
                first_sample['healthy_feats'][:,t],first_sample['healthy_delta'][t])
            assert not v.ready and v.alerts is None
        try:ss.ingest(299,np.zeros(3),np.zeros(7),np.zeros((2,7,3)),np.zeros((7,3)))
        except ValueError:pass
        else:raise AssertionError('Wrong observation shape should be rejected')
        assert ss._next_seq==299,'Invalid report advanced state'
        try:ss.ingest(300,first_sample['healthy_v11'][299],first_sample['healthy_v11_named'][299],
                      first_sample['healthy_feats'][:,299],first_sample['healthy_delta'][299])
        except ValueError:pass
        else:raise AssertionError('Out of order should be rejected')
        v=ss.ingest(299,first_sample['healthy_v11'][299],first_sample['healthy_v11_named'][299],
                first_sample['healthy_feats'][:,299],first_sample['healthy_delta'][299])
        assert v.ready and v.action=='NO_HARDWARE_ACTUATION' and v.reports_seen==300
        try:ss.ingest(300,first_sample['healthy_v11'][299],first_sample['healthy_v11_named'][299],
                      first_sample['healthy_feats'][:,299],first_sample['healthy_delta'][299])
        except RuntimeError:pass
        else:raise AssertionError('Overfilled session should reject')
        ss.reset();assert ss._next_seq==0
    summary['streams_tested']=count
    summary['max_probability_abs_error']=max_prob
    summary['max_693_feature_abs_error']=max_feature
    summary['max_79_feature_abs_error']=max_upstream
    summary['total_elapsed_seconds']=(time.perf_counter_ns()-t0)/1e9
    if output:Path(output).write_text(json.dumps(summary,indent=2))
    print('ENGINEERING_REGRESSION_PASS',count,'streams','prob_err',max_prob,'feature_err',max_feature,'79err',max_upstream)
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('files',nargs='+');ap.add_argument('--output')
    args=ap.parse_args();run([Path(p) for p in args.files],args.output)
