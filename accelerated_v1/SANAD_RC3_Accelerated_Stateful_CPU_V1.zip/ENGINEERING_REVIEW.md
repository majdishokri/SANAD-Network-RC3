# SANAD Network RC3 — accelerated execution & second-pass software engineering audit

**Status:** Engine-only candidate; original RC3 frozen source/weights/decision threshold unchanged. Not a new or independent RF/field qualification. Date: 2026-11-17.

## What was actually inspected

- The frozen RC3 entry point (`frozen/rc3.py`) and verified model files (compressed RC3, upstream RC0).
- Original `feature_engineering.py`, v33/v34/v35 state-fusion modules, learned gate, model feature definition (693 + 15 spatial and 79 upstream selected features).
- Eight Sionna evidence seeds (**3044, 3054, 3069, 3084, 3099, 3114, 3129, 3143**), each healthy and injected: **16 streams**, 4,800 reports total (4,784 nonterminal reports).
- Prior frozen qualification checkpoints and outcomes. Unqualified variants were not substituted.
- Earlier retrospective benchmark and its avoidable 72-candidate comparator replay (already handled by the previous audit).

## Confirmed bottlenecks and changes

| Bottleneck (original) | Engineering correction (candidate) | Scientific change? |
|---|---|---|
| Every endpoint call replays 300 reports through both v33 and v35 Python state machines | `RC3IngestionSession.push()` processes **each new report once** and retains causal state; terminal scoring runs after exactly report 300 | **No**; both original state machine `step()` methods are used unchanged |
| Every RC3 call builds 693 statistics per array via >1,000 small `numpy.quantile`/`numpy.std` calls | Numba `fast_stats.py`: same windows, NaN/finite handling, feature order and float32 output | **No**; differential error ≤2.98×10⁻⁸ across tested streams |
| 1,912 forest estimator dispatches through `sklearn.ensemble`/joblib for only seven rows | `fast_trees.py`: compiled tree traversals using original tree arrays and class probabilities | **No**; decision parity, max probability difference ≤5.56×10⁻¹⁷ tested |
| Upstream 79-feature endpoint repeatedly invokes scalar `np.quantile` and builds Python dictionaries | `fast_upstream.py` compiled equivalent, preserving **exact 79-column order and values** | **No**; exact equality across tested streams |
| Per-report Python lists and final `np.stack` | Typed, fixed-size per-session arrays, preallocated replay flags | **No** |
| Silent report-order and duplicate risk | `MonitorService` rejects gaps/out-of-order IDs; never emits a decision before report 300; explicit reset | Protocol improvement only |
| Cold JIT overhead could be confused with p95 processing time | Prewarm Numba functions before traffic; cold startup recorded separately | Metric hygiene |

The 300-report replay, v33/v35 fusion loops, 693 input statistics and 79 upstream features are **not dead logic**. Deleting them would change the detector; instead, the candidate preserves their semantics and moves historical replay into per-report incremental ingestion. No frozen module is edited or overwritten.

## Provenance and differential tests

- Frozen original `rc3.py` SHA-256: `c5fbae4163a8df5d17546c773b8c015ee79a0d5dc462867e9dab0f17c731f23c`.
- Frozen original 693-feature source SHA-256: `18cccfaa9b27a17934bc2c3a1c22f0b7ed164b2af99c0ad738b33a595357a81e`.
- Frozen model uncompressed SHA-256: `0a90835bb57a56437fc09211902b581bb22377676f91dce68f309c92e3a95bf4`.
- Original threshold: **0.50**; original geometry **7×8**; original qualification **274/288 TP, 0/1008 healthy-only FP, 13/720 neighbor FP** on simulated Sionna evidence.
- `tests.py`: 8 seeds × 2 streams; exact **alert parity** between original stateless, accelerated stateless and incrementally ingested terminal model. Maximum observed absolute probability difference **5.56e-17**. Maximum observed 693-feature absolute float32 difference **2.98e-8**; 79 upstream feature differences **0**. Fail-closed invalid schema/ordering and no early RC3 output checked.
- `validate_full.py`: exact source SHA, model SHA, evidence SHA and per-seed original checkpoint counts are required. Colab rejects output if **any** of 144 original frozen checkpoints or aggregate counts differ. The complete 144-seed *accelerated* run was **not** executed in this local environment; Colab performs it.

## Local warm-CPU performance (8 seeds × 2 streams)

These are local measurements on one Python 3.13 machine after JIT warmup, not the user's Colab hardware and not an operational RF SLA. See `performance_local.json` for all per-seed timings and percentiles.

| Workload | p95 (ms) | Notes |
|---|---:|---|
| Original frozen RC3, full 300-report stream | **320.08** | On this machine, not 764 ms previously reported on Colab |
| Accelerated stateless replay, full stream | **150.92** | Still replays the original 300 steps each call; ~53% lower p95 |
| Incremental ingestion of **one ordinary report** | **0.733** | 4,784 report calls, p95 after warmup; no RC3 terminal decision yet |
| 300th report **including full RC3 terminal classification** | **4.67** | 16 terminal evaluations; p95 includes endpoint scoring |

**Neither 0.733 nor 4.67 ms is time to detect an RF failure.** The frozen model still requires 300 simulated reports. **Streaming ingestion does not create real-time early alarms.** A separate, newly trained and independently validated early-warning model would be needed to claim earlier detection. The full covariance/pilot/signal capture path and any hardware/communications latency are outside these timings.

## Second-pass code structure and libraries review

1. **Separation of concerns:** `service.py` (sequence validation and no-actuation API) → `fast_engine.py` (stateful 300-report ingestion and frozen model orchestration) → `fast_upstream.py`/`fast_stats.py` (compiled deterministic features) → `fast_trees.py` (compiled tree traversal), while `frozen/` remains an immutable trusted reference.
2. **No unnecessary model retraining:** original learned trees, HGB model, logistic pipeline, RC0 gate, and threshold preserved; pure implementation acceleration. No `EWMA/CUSUM` code is in production candidate.
3. **Dependency pinning:** NumPy 2.3.5, scikit-learn 1.8.0, joblib 1.5.3, Numba 0.65.1. Loading serialized models is safe only from the hash-verified trusted archive. Numba JIT uses additional startup memory/time, measured separately.
4. **Input validation:** rejects invalid antenna IDs, partially missing triplets, infinity, non-binary V11 flags, malformed geometry and out-of-order sequence IDs. Re-validates source schema when running stateless. Structured `NO_HARDWARE_ACTUATION` output.
5. **Memory and concurrency:** fixed-size typed 300×7 buffers prevent unbounded growth; a lock serializes session updates and rejects duplicates. A production multi-tenant fleet would need per-network partitions and durable sequence checkpoints, not one global session.
6. **Data integrity:** original source and model SHA, prior per-seed evidence SHA, original frozen model output parity and checkpoint totals. Numerical near-threshold fallback uses the original estimator where appropriate.
7. **Remaining hot path:** Python v33/v35 state-machine `step()` implementations consume most ordinary per-report CPU. A future compiled state machine is possible but **would require a separate exact-state equivalence proof**, including all missingness/cohort/identity edge cases. Do not remove it on performance grounds alone.
8. **Missing operational components:** this package expects precomputed V11/fast/strict/temporal evidence. It is not connected to live RF calibration hardware; it contains no raw-IQ ingestion, calibrated absolute clock, network resilience/queueing, telemetry database or actuation. Those must be engineered and separately benchmarked for any client SLA.
9. **Testing gaps:** currently eight sample seeds are locally verified; full 144-seed parity is an explicit Colab gate. New hardware-annotated faults and verified healthy controls remain necessary for field detection recall and FAR. New streaming first-alert TTD still **not measurable** for the frozen terminal RC3.

## Recommended next releases

- **V1.0 accelerated RC3 executor:** ship only after `validate_full.py` reports `FULL_PARITY_PASS` on all 144 original checkpoints. This is safe *execution modernization*, not new model qualification.
- **Separate RC4 streaming research:** collect longer continuous RF traces, add correct per-report labels/onset timestamps, train early-warning scoring with prospective unused seeds; measure TTD at the same FAR and compare end-to-end against EWMA/CUSUM.
- **Commercial deployment gate:** verified hardware/geometry, fixed clock and pilot references, signed telemetry, independent healthy/faulty annotations, device-specific p95/p99 end-to-end latency, sustained workload and failure injection tests.

### Data-quality regression extension

Five additional adversarial but schema-valid perturbations on the original s3143 evidence were compared against the frozen model: a missing fast-evidence block, missing temporal delta block, common-mode score increase, temporarily absent raw V11 flags, and one station with missing evidence over its last 100 reports. All five retained **identical terminal decisions**, with absolute probability differences at or below about 1e-19. These tests establish implementation parity on selected edge inputs, **not** the model's fault-detection accuracy under such perturbations.
