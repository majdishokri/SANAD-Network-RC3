"""Strict parity and latency protocol for the original 144 frozen RC3 seeds.

This does NOT create a new independent test: it reuses prospective Sionna
seeds 3000..3143, on which the original RC3 accuracy was previously evaluated.
Labels read only after predictions; all original RC3 checkpoint hashes checked.
"""
from __future__ import annotations
from pathlib import Path
import argparse, json, hashlib, sys, platform, time, resource, statistics, os
import numpy as np
from fast_engine import FastRC3

ROOT=Path(__file__).resolve().parent
EXPECTED_SOURCE='121ce9aba417fb27b07d7f7f6e52633a8ef29a2c99aefddc12a10428d02ddafb'
EXPECTED_MODEL='0a90835bb57a56437fc09211902b581bb22377676f91dce68f309c92e3a95bf4'


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for buf in iter(lambda:f.read(2**20),b''):h.update(buf)
    return h.hexdigest()

def dist(xs):
    if not xs:return {'n':0,'p50_ms':None,'p95_ms':None,'p99_ms':None,'max_ms':None}
    x=np.asarray(xs,dtype=float)
    return {'n':len(x),'p50_ms':float(np.percentile(x,50)),
            'p95_ms':float(np.percentile(x,95)),
            'p99_ms':float(np.percentile(x,99)),
            'max_ms':float(np.max(x))}

def run(evidence,checkpoints,out,start=3000,end=3143):
    evidence=Path(evidence);checkpoints=Path(checkpoints);out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    assert 3000<=start<=end<=3143
    import sklearn, numba, joblib
    versions={'python':platform.python_version(),'numpy':np.__version__,
              'sklearn':sklearn.__version__,'numba':numba.__version__,
              'joblib':joblib.__version__}
    if (versions['numpy'],versions['sklearn'],versions['numba'],versions['joblib'])!=('2.3.5','1.8.0','0.65.1','1.5.3'):
        raise RuntimeError('Incompatible scientific runtime: '+str(versions))
    start_ns=time.perf_counter_ns();m=FastRC3();startup_ms=(time.perf_counter_ns()-start_ns)/1e6
    print('ENGINE_INITIALIZED_INCLUDING_JIT',round(startup_ms,2),'ms',flush=True)
    rows=[];t_original=[];t_fast=[];t_ingest=[];t_terminal=[]
    totals={'tp':0,'fault_n':0,'healthy_fp':0,'healthy_n':0,'neighbor_fp':0,'neighbor_n':0}
    maxprob=0.0
    for seed in range(start,end+1):
        file=evidence/f's{seed}.npz';ck=checkpoints/f's{seed}.json'
        if not file.exists() or not ck.exists():raise FileNotFoundError(f'Missing original immutable {seed}: {file} / {ck}')
        chk=json.loads(ck.read_text())
        assert chk['seed']==seed and chk['source_sha256']==EXPECTED_SOURCE
        assert chk['model_sha256']==EXPECTED_MODEL and chk['decision_threshold']==0.5
        actual_sha=sha(file)
        if actual_sha!=chk['evidence_sha256']:
            raise RuntimeError('Original evidence hash mismatch for '+str(seed))
        with np.load(file,allow_pickle=False) as z:
            trace={k:z[k] for k in z.files}
        predicted={}; row={'seed':seed,'evidence_sha256':actual_sha,'stream':{}}
        for stream in ('healthy','injected'):
            t=time.perf_counter_ns();ref=m.reference.predict_trace(trace,stream);tr=(time.perf_counter_ns()-t)/1e6
            t=time.perf_counter_ns();fast=m.predict_trace(trace,stream);tf=(time.perf_counter_ns()-t)/1e6
            session=m.session(stream);times=[];new=None
            for i in range(300):
                t=time.perf_counter_ns()
                new=session.push(trace[f'{stream}_v11'][i],trace[f'{stream}_v11_named'][i],
                                 trace[f'{stream}_feats'][:,i],trace[f'{stream}_delta'][i])
                times.append((time.perf_counter_ns()-t)/1e6)
                if i<299 and new is not None:raise RuntimeError('Premature RC3 terminal prediction')
            if new is None:raise RuntimeError('No terminal RC3 prediction')
            if ref['alerts']!=fast['alerts'] or ref['alerts']!=new['alerts']:
                raise RuntimeError(f'RC3 decisions changed: seed {seed} {stream}')
            diff=max(abs(a-b) for a,b in zip(ref['probabilities'],new['probabilities']))
            if diff>1e-7:raise RuntimeError(f'RC3 probability mismatch {seed}: {diff}')
            maxprob=max(maxprob,diff)
            t_original.append(tr);t_fast.append(tf);t_ingest.extend(times[:-1]);t_terminal.append(times[-1])
            predicted[stream]=np.asarray(new['alerts'],dtype=bool)
            row['stream'][stream]={'reference_ms':tr,'optimized_full_ms':tf,
                'incremental_ingest_p95_ms':float(np.percentile(times[:-1],95)),
                'terminal_report_ms':times[-1],'max_prob_abs_error':diff}
        ground=np.asarray(trace['injected_expected'])>0
        control=np.asarray(trace['healthy_expected'])>0
        assert ground.shape==control.shape==(7,) and ground.sum()==2 and not control.any()
        tp=int(np.sum(predicted['injected']&ground))
        hf=int(np.sum(predicted['healthy']))
        nf=int(np.sum(predicted['injected']&~ground))
        if (tp,hf,nf)!=(chk['methods']['RC3']['tp'],chk['methods']['RC3']['healthy_fp'],chk['methods']['RC3']['neighbor_fp']):
            raise RuntimeError('Original checkpoint did not match for '+str(seed))
        totals['tp']+=tp;totals['fault_n']+=2;totals['healthy_fp']+=hf;totals['healthy_n']+=7
        totals['neighbor_fp']+=nf;totals['neighbor_n']+=5
        row['rc3_counts']={'tp':tp,'healthy_fp':hf,'neighbor_fp':nf}
        rows.append(row)
        (out/'progress_latest.json').write_text(json.dumps({'completed':seed-start+1,'total':end-start+1,'last_seed':seed,'status':'RUNNING'},indent=2))
        if (seed-start+1)%8==0 or seed==end:
            print('VERIFIED',seed-start+1,'/',end-start+1,'last',seed,flush=True)
    full=(start,end)==(3000,3143)
    if full and (totals['tp'],totals['fault_n'],totals['healthy_fp'],totals['healthy_n'],totals['neighbor_fp'],totals['neighbor_n'])!=(274,288,0,1008,13,720):
        raise RuntimeError('Original 144-seed frozen RC3 simulation acceptance counts NOT reproduced')
    rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    summary={'status':'FULL_PARITY_PASS' if full else 'PARTIAL_PARITY_PASS',
       'completed_seeds':end-start+1,'seed_range':[start,end],
       'frozen_threshold':0.5,'unchanged_model_sha256':EXPECTED_MODEL,
       'source_sha256':EXPECTED_SOURCE,
       'scientific_status':'REUSED_SIMULATED_EVIDENCE_NOT_INDEPENDENT_OR_FIELD_VALIDATION',
       'engine_includes_original_model':True,
       'online_first_alarm_ttd_hours':None,
       'ttd_note':'Terminal-only 300-report RC3. Fast push() does not change the detector\'s first-alert time.',
       '15_minute_report_period_is_simulated':True,
       'cold_engine_startup_including_jit_ms':startup_ms,
       'original_full_300_report_stream':dist(t_original),
       'fast_full_300_report_stream':dist(t_fast),
       'incremental_ordinary_report_update':dist(t_ingest),
       'incremental_final_report_including_scoring':dist(t_terminal),
       'maximum_prediction_probability_abs_error':maxprob,
       'totals':totals,
       'cpu_max_rss_kib':int(rss_kib),
       'versions':versions,
       'hardware':'CPU only; Sionna evidence replay, no RF front-end IQ/covariance cost measured',
       'original_prospective_study':'SANAD_RC3_SPATIAL_META_FROZEN_0p50_GPU_PROSPECTIVE_3000_3143'}
    (out/'fast_latency_and_parity_summary.json').write_text(json.dumps(summary,indent=2))
    (out/'fast_per_seed_details.json').write_text(json.dumps(rows,indent=2))
    (out/'progress_latest.json').write_text(json.dumps({'completed':end-start+1,'total':end-start+1,'status':'PASS'},indent=2))
    print('FINAL_PARITY_AND_LATENCY',json.dumps({k:summary[k] for k in ('status','totals','original_full_300_report_stream','fast_full_300_report_stream','incremental_ordinary_report_update','incremental_final_report_including_scoring')},indent=2))
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--evidence',required=True);p.add_argument('--checkpoints',required=True)
    p.add_argument('--out',required=True);p.add_argument('--start',type=int,default=3000);p.add_argument('--end',type=int,default=3143)
    a=p.parse_args();run(a.evidence,a.checkpoints,a.out,a.start,a.end)
